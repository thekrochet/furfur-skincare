import React, { useState, useEffect } from 'react';
import { collection, getDocs, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import AdminLayout from './AdminLayout';
import { Trash2, Star, User } from 'lucide-react';

interface Review {
  id: string;
  name: string;
  productId: string;
  productName?: string;
  rating: number;
  comment: string;
  date: any;
}

export default function AdminReviews() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    fetchReviews();
  }, []);

  async function fetchReviews() {
    setLoading(true);
    try {
      const q = query(collection(db, 'reviews'), orderBy('date', 'desc'));
      const querySnapshot = await getDocs(q);
      
      // Also fetch products to get product names if needed
      const productsSnap = await getDocs(collection(db, 'products'));
      const productsMap = new Map();
      productsSnap.docs.forEach(doc => productsMap.set(doc.id, doc.data().name));

      const reviewsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        productName: productsMap.get(doc.data().productId) || 'Unknown Product',
        ...doc.data()
      })) as Review[];
      
      setReviews(reviewsData);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'reviews', id));
      setReviews(reviews.filter(r => r.id !== id));
      setDeleteConfirmId(null);
    } catch (error) {
      console.error('Error deleting review:', error);
      alert('Failed to delete review.');
    }
  };

  return (
    <AdminLayout>
      <header className="mb-10">
        <h1 className="text-3xl font-serif mb-2">Reviews</h1>
        <p className="text-gray-500 text-sm">Monitor and manage customer feedback.</p>
      </header>

      <div className="grid grid-cols-1 gap-6">
        {loading ? (
          <div className="text-center py-20 text-gray-400">Loading reviews...</div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-20 text-gray-400">No reviews found.</div>
        ) : (
          reviews.map((review) => (
            <div key={review.id} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center text-gray-400">
                    <User size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{review.name}</h3>
                    <p className="text-xs text-gray-400">
                      {review.date?.toDate ? review.date.toDate().toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setDeleteConfirmId(review.id)}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                >
                  <Trash2 size={20} />
                </button>
              </div>

              <div className="mb-4">
                <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">Product</p>
                <p className="text-sm font-medium text-black">{review.productName}</p>
              </div>

              <div className="mb-4">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      size={16} 
                      className={i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'} 
                    />
                  ))}
                </div>
                <p className="text-gray-600 leading-relaxed italic">"{review.comment}"</p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setDeleteConfirmId(null)} />
          <div className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl p-8 animate-in fade-in zoom-in duration-200">
            <h2 className="text-2xl font-serif mb-4">Delete Review?</h2>
            <p className="text-gray-500 mb-8">This action cannot be undone. Are you sure you want to remove this review?</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-6 py-3 border border-gray-100 rounded-xl font-bold hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => handleDelete(deleteConfirmId)}
                className="flex-1 px-6 py-3 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
