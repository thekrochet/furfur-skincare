import React, { useState, useEffect } from 'react';
import { ShoppingCart, Package, MessageSquare, Plus, ArrowRight, Users, IndianRupee } from 'lucide-react';
import { Link } from 'react-router-dom';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import AdminLayout from './AdminLayout';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    orders: 0,
    revenue: 0,
    products: 0,
    customers: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubOrders = onSnapshot(collection(db, 'orders'), (snapshot) => {
      let revenue = 0;
      snapshot.forEach(doc => {
        const data = doc.data();
        revenue += Number(data.totalPrice || 0);
      });
      setStats(prev => ({ ...prev, orders: snapshot.size, revenue }));
      setLoading(false);
    }, (error) => {
      console.error("Error fetching orders:", error);
    });

    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      setStats(prev => ({ ...prev, products: snapshot.size }));
    }, (error) => {
      console.error("Error fetching products:", error);
    });

    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setStats(prev => ({ ...prev, customers: snapshot.size }));
    }, (error) => {
      console.error("Error fetching users:", error);
    });

    return () => {
      unsubOrders();
      unsubProducts();
      unsubUsers();
    };
  }, []);

  const statCards = [
    { label: 'Total Orders', value: stats.orders, icon: ShoppingCart },
    { label: 'Total Revenue', value: `₹${stats.revenue.toLocaleString()}`, icon: IndianRupee },
    { label: 'Total Products', value: stats.products, icon: Package },
    { label: 'Total Customers', value: stats.customers, icon: Users },
  ];

  return (
    <AdminLayout>
      <header className="mb-10">
        <h1 className="text-3xl font-serif mb-2">Dashboard</h1>
        <p className="text-gray-500 text-sm">Overview of your store's performance.</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-12">
        {statCards.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 sm:p-8 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-gray-50 rounded-xl text-black">
                <stat.icon size={24} />
              </div>
            </div>
            <p className="text-[10px] sm:text-xs text-gray-400 uppercase tracking-widest mb-1 font-bold">{stat.label}</p>
            <h3 className="text-2xl sm:text-3xl font-bold">{loading ? '...' : stat.value}</h3>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <section className="mb-12">
        <h2 className="text-xl font-serif mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link 
            to="/admin/products" 
            className="flex items-center justify-between p-6 bg-black text-white rounded-2xl hover:bg-gray-900 transition-colors group"
          >
            <div className="flex items-center gap-4">
              <Plus size={20} />
              <span className="font-medium">Add Product</span>
            </div>
            <ArrowRight size={18} className="opacity-0 group-hover:opacity-100 transition-opacity" />
          </Link>
          
          <Link 
            to="/admin/orders" 
            className="flex items-center justify-between p-6 bg-white border border-gray-100 rounded-2xl hover:bg-gray-50 transition-colors group"
          >
            <div className="flex items-center gap-4 text-black">
              <ShoppingCart size={20} />
              <span className="font-medium">View Orders</span>
            </div>
            <ArrowRight size={18} className="text-gray-300 group-hover:text-black transition-colors" />
          </Link>

          <Link 
            to="/admin/reviews" 
            className="flex items-center justify-between p-6 bg-white border border-gray-100 rounded-2xl hover:bg-gray-50 transition-colors group"
          >
            <div className="flex items-center gap-4 text-black">
              <MessageSquare size={20} />
              <span className="font-medium">Manage Reviews</span>
            </div>
            <ArrowRight size={18} className="text-gray-300 group-hover:text-black transition-colors" />
          </Link>
        </div>
      </section>
    </AdminLayout>
  );
}

