import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import AdminLayout from './AdminLayout';
import { Plus, Edit2, Trash2, X, Search } from 'lucide-react';

interface Variant {
  size: string;
  mrp: number;
  price: number;
}

interface Ingredient {
  name: string;
  benefit: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  description: string;
  image: string;
  images?: string[];
  rating: number;
  skinType: string;
  benefits?: string[];
  variants?: Variant[];
  ingredients?: Ingredient[];
}

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSkinType, setSelectedSkinType] = useState('All');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    price: '',
    mrp: '',
    category: '',
    description: '',
    image: '',
    images: [] as string[],
    rating: '5',
    skinType: '',
    benefits: [] as string[],
    variants: [] as Variant[],
    ingredients: [] as Ingredient[]
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  async function fetchProducts() {
    setLoading(true);
    try {
      const querySnapshot = await getDocs(collection(db, 'products'));
      const productsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Product[];
      setProducts(productsData);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleOpenModal = (product: Product | null = null) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        price: product.price.toString(),
        mrp: (product as any).mrp?.toString() || '',
        category: product.category,
        description: product.description,
        image: product.image,
        images: product.images || (product.image ? [product.image] : []),
        rating: product.rating.toString(),
        skinType: product.skinType,
        benefits: product.benefits || [],
        variants: product.variants || [],
        ingredients: product.ingredients || []
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: '',
        price: '',
        mrp: '',
        category: '',
        description: '',
        image: '',
        images: [],
        rating: '5',
        skinType: '',
        benefits: [],
        variants: [],
        ingredients: []
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const productData = {
      ...formData,
      image: formData.images.length > 0 ? formData.images[0] : formData.image,
      price: parseFloat(formData.price),
      mrp: formData.mrp ? parseFloat(formData.mrp) : 0,
      rating: parseFloat(formData.rating),
      variants: formData.variants.map(v => ({
        ...v,
        mrp: parseFloat(v.mrp as any),
        price: parseFloat(v.price as any)
      })),
      ingredients: formData.ingredients
    };

    try {
      if (editingProduct) {
        await updateDoc(doc(db, 'products', editingProduct.id), productData);
      } else {
        await addDoc(collection(db, 'products'), productData);
      }
      setIsModalOpen(false);
      fetchProducts();
    } catch (error) {
      console.error('Error saving product:', error);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
      setDeleteConfirmId(null);
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Failed to delete product. Check console for details.');
    }
  };

  let filteredProducts = products.filter(p => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.category && p.category.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.skinType && p.skinType.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || (p.category && p.category.toLowerCase() === selectedCategory.toLowerCase());
    const matchesSkinType = selectedSkinType === 'All' || (p.skinType && p.skinType.toLowerCase() === selectedSkinType.toLowerCase());

    return matchesSearch && matchesCategory && matchesSkinType;
  });

  if (sortOrder) {
    filteredProducts.sort((a, b) => {
      const priceA = a.variants && a.variants.length > 0 ? a.variants[0].price : a.price;
      const priceB = b.variants && b.variants.length > 0 ? b.variants[0].price : b.price;
      return sortOrder === 'asc' ? priceA - priceB : priceB - priceA;
    });
  }

  return (
    <AdminLayout>
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-serif mb-2">Products</h1>
          <p className="text-gray-500 text-sm">Manage your product catalog.</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-900 transition-all font-medium"
        >
          <Plus size={20} />
          Add Product
        </button>
      </header>

      {/* Filters & Search */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="Search by name, category, or skin type..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-black/5 transition-all"
          />
        </div>

        {/* Category Filter */}
        <select 
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
        >
          <option value="All">All Categories</option>
          <option value="Serum">Serum</option>
          <option value="Facewash">Facewash</option>
          <option value="Moisturizer">Moisturizer</option>
          <option value="Sunscreen">Sunscreen</option>
        </select>

        {/* Skin Type Filter */}
        <select 
          value={selectedSkinType}
          onChange={(e) => setSelectedSkinType(e.target.value)}
          className="px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
        >
          <option value="All">All Skin Types</option>
          <option value="Oily">Oily</option>
          <option value="Dry">Dry</option>
          <option value="Combination">Combination</option>
          <option value="Sensitive">Sensitive</option>
        </select>

        {/* Sort Buttons */}
        <div className="flex gap-2">
          <button 
            onClick={() => setSortOrder(sortOrder === 'asc' ? null : 'asc')}
            className={`px-4 py-3 border rounded-2xl font-medium text-sm transition-all ${sortOrder === 'asc' ? 'bg-black text-white border-black' : 'bg-gray-50 text-gray-700 border-gray-100 hover:border-gray-300'}`}
          >
            Low → High
          </button>
          <button 
            onClick={() => setSortOrder(sortOrder === 'desc' ? null : 'desc')}
            className={`px-4 py-3 border rounded-2xl font-medium text-sm transition-all ${sortOrder === 'desc' ? 'bg-black text-white border-black' : 'bg-gray-50 text-gray-700 border-gray-100 hover:border-gray-300'}`}
          >
            High → Low
          </button>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-gray-400">Product</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-gray-400">Category</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-gray-400">Price</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-gray-400">Rating</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-gray-400 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-400">Loading products...</td>
                </tr>
              ) : filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-400">No products found.</td>
                </tr>
              ) : (
                filteredProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <img 
                          src={product.image || undefined} 
                          alt={product.name} 
                          className="w-12 h-12 object-cover rounded-xl bg-gray-100"
                          referrerPolicy="no-referrer"
                        />
                        <span className="font-medium text-gray-900">{product.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-500">{product.category}</td>
                    <td className="px-6 py-4 font-medium">
                      ₹{product.variants && product.variants.length > 0 ? product.variants[0].price : product.price}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <span className="text-sm font-bold">{product.rating}</span>
                        <span className="text-yellow-400">★</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => handleOpenModal(product)}
                          className="p-2 text-gray-400 hover:text-black hover:bg-white rounded-lg transition-all"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button 
                          onClick={() => setDeleteConfirmId(product.id)}
                          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setDeleteConfirmId(null)} />
          <div className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl p-8 animate-in fade-in zoom-in duration-200">
            <h2 className="text-2xl font-serif mb-4">Delete Product?</h2>
            <p className="text-gray-500 mb-8">This action cannot be undone. Are you sure you want to remove this product from your catalog?</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-6 py-3 border border-gray-100 rounded-xl font-bold hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => handleDelete(deleteConfirmId)}
                className="flex-1 px-6 py-3 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsModalOpen(false)} />
          <div className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center p-8 border-b border-gray-100">
              <h2 className="text-2xl font-serif">{editingProduct ? 'Edit Product' : 'Add New Product'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-50 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Product Name</label>
                  <input 
                    required
                    type="text" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Price (₹)</label>
                  <input 
                    required
                    type="number" 
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">MRP (₹) - Optional</label>
                  <input 
                    type="number" 
                    value={formData.mrp}
                    onChange={(e) => setFormData({...formData, mrp: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Category</label>
                  <input 
                    required
                    type="text" 
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Skin Type</label>
                  <input 
                    required
                    type="text" 
                    value={formData.skinType}
                    onChange={(e) => setFormData({...formData, skinType: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Rating (1-5)</label>
                  <input 
                    required
                    type="number" 
                    min="1" 
                    max="5" 
                    step="0.1"
                    value={formData.rating}
                    onChange={(e) => setFormData({...formData, rating: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                  />
                </div>

                {/* Images Section */}
                <div className="col-span-2">
                  <div className="flex justify-between items-center mb-4">
                    <label className="block text-xs font-bold uppercase tracking-widest text-gray-400">Product Images</label>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, images: [...formData.images, '']})}
                      className="text-xs font-bold text-black hover:underline flex items-center gap-1"
                    >
                      <Plus size={14} />
                      Add Image
                    </button>
                  </div>
                  <div className="space-y-3">
                    {formData.images.map((imgUrl, idx) => (
                      <div key={idx} className="flex gap-2">
                        <input 
                          type="url" 
                          value={imgUrl}
                          onChange={(e) => {
                            const newImages = [...formData.images];
                            newImages[idx] = e.target.value;
                            setFormData({...formData, images: newImages});
                          }}
                          placeholder="https://example.com/image.jpg"
                          className="flex-1 px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                        />
                        <button 
                          type="button"
                          onClick={() => {
                            const newImages = formData.images.filter((_, i) => i !== idx);
                            setFormData({...formData, images: newImages});
                          }}
                          className="p-3 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                        >
                          <X size={20} />
                        </button>
                      </div>
                    ))}
                    {formData.images.length === 0 && (
                      <p className="text-xs text-gray-400 italic">No images added. Please add at least one image.</p>
                    )}
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Description</label>
                  <textarea 
                    required
                    rows={4}
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5 resize-none"
                  />
                </div>

                {/* Benefits Section */}
                <div className="col-span-2">
                  <div className="flex justify-between items-center mb-4">
                    <label className="block text-xs font-bold uppercase tracking-widest text-gray-400">Key Benefits</label>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, benefits: [...formData.benefits, '']})}
                      className="text-xs font-bold text-black hover:underline flex items-center gap-1"
                    >
                      <Plus size={14} />
                      Add Benefit
                    </button>
                  </div>
                  <div className="space-y-3">
                    {formData.benefits.map((benefit, idx) => (
                      <div key={idx} className="flex gap-2">
                        <input 
                          type="text" 
                          value={benefit}
                          onChange={(e) => {
                            const newBenefits = [...formData.benefits];
                            newBenefits[idx] = e.target.value;
                            setFormData({...formData, benefits: newBenefits});
                          }}
                          placeholder="e.g. Hydration"
                          className="flex-1 px-4 py-2 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5"
                        />
                        <button 
                          type="button"
                          onClick={() => {
                            const newBenefits = formData.benefits.filter((_, i) => i !== idx);
                            setFormData({...formData, benefits: newBenefits});
                          }}
                          className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <X size={18} />
                        </button>
                      </div>
                    ))}
                    {formData.benefits.length === 0 && (
                      <p className="text-xs text-gray-400 italic">No benefits added yet.</p>
                    )}
                  </div>
                </div>

                {/* Variants Section */}
                <div className="col-span-2">
                  <div className="flex justify-between items-center mb-4">
                    <label className="block text-xs font-bold uppercase tracking-widest text-gray-400">Product Variants</label>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, variants: [...formData.variants, { size: '', mrp: 0, price: 0 }]})}
                      className="text-xs font-bold text-black hover:underline flex items-center gap-1"
                    >
                      <Plus size={14} />
                      Add Variant
                    </button>
                  </div>
                  <div className="space-y-4">
                    {formData.variants.map((variant, idx) => (
                      <div key={idx} className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100 relative">
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-gray-400 mb-1">Size</label>
                          <input 
                            type="text" 
                            value={variant.size}
                            onChange={(e) => {
                              const newVariants = [...formData.variants];
                              newVariants[idx].size = e.target.value;
                              setFormData({...formData, variants: newVariants});
                            }}
                            placeholder="e.g. 50g"
                            className="w-full px-3 py-2 bg-white border border-gray-100 rounded-lg text-sm focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-gray-400 mb-1">MRP (₹)</label>
                          <input 
                            type="number" 
                            value={variant.mrp}
                            onChange={(e) => {
                              const newVariants = [...formData.variants];
                              newVariants[idx].mrp = e.target.value as any;
                              setFormData({...formData, variants: newVariants});
                            }}
                            className="w-full px-3 py-2 bg-white border border-gray-100 rounded-lg text-sm focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-gray-400 mb-1">Price (₹)</label>
                          <input 
                            type="number" 
                            value={variant.price}
                            onChange={(e) => {
                              const newVariants = [...formData.variants];
                              newVariants[idx].price = e.target.value as any;
                              setFormData({...formData, variants: newVariants});
                            }}
                            className="w-full px-3 py-2 bg-white border border-gray-100 rounded-lg text-sm focus:outline-none"
                          />
                        </div>
                        <div className="flex items-end">
                          <button 
                            type="button"
                            onClick={() => {
                              const newVariants = formData.variants.filter((_, i) => i !== idx);
                              setFormData({...formData, variants: newVariants});
                            }}
                            className="w-full py-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors text-xs font-bold"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                    {formData.variants.length === 0 && (
                      <p className="text-xs text-gray-400 italic">No variants added. Product will use the default price.</p>
                    )}
                  </div>
                </div>

                {/* Ingredients Section */}
                <div className="col-span-2">
                  <div className="flex justify-between items-center mb-4">
                    <label className="block text-xs font-bold uppercase tracking-widest text-gray-400">Key Ingredients</label>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, ingredients: [...formData.ingredients, { name: '', benefit: '' }]})}
                      className="text-xs font-bold text-black hover:underline flex items-center gap-1"
                    >
                      <Plus size={14} />
                      Add Ingredient
                    </button>
                  </div>
                  <div className="space-y-4">
                    {formData.ingredients.map((ingredient, idx) => (
                      <div key={idx} className="grid grid-cols-1 sm:grid-cols-5 gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100 relative">
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold uppercase text-gray-400 mb-1">Ingredient Name</label>
                          <input 
                            type="text" 
                            value={ingredient.name}
                            onChange={(e) => {
                              const newIngredients = [...formData.ingredients];
                              newIngredients[idx].name = e.target.value;
                              setFormData({...formData, ingredients: newIngredients});
                            }}
                            placeholder="e.g. Niacinamide"
                            className="w-full px-3 py-2 bg-white border border-gray-100 rounded-lg text-sm focus:outline-none"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold uppercase text-gray-400 mb-1">Benefit</label>
                          <input 
                            type="text" 
                            value={ingredient.benefit}
                            onChange={(e) => {
                              const newIngredients = [...formData.ingredients];
                              newIngredients[idx].benefit = e.target.value;
                              setFormData({...formData, ingredients: newIngredients});
                            }}
                            placeholder="e.g. Reduces pores"
                            className="w-full px-3 py-2 bg-white border border-gray-100 rounded-lg text-sm focus:outline-none"
                          />
                        </div>
                        <div className="flex items-end">
                          <button 
                            type="button"
                            onClick={() => {
                              const newIngredients = formData.ingredients.filter((_, i) => i !== idx);
                              setFormData({...formData, ingredients: newIngredients});
                            }}
                            className="w-full py-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors text-xs font-bold"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                    {formData.ingredients.length === 0 && (
                      <p className="text-xs text-gray-400 italic">No ingredients added yet.</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-10 flex gap-4">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-6 py-4 border border-gray-100 rounded-2xl font-bold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-6 py-4 bg-black text-white rounded-2xl font-bold hover:bg-gray-900 transition-colors"
                >
                  {editingProduct ? 'Update Product' : 'Save Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
