import React, { createContext, useContext, useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp, getDocs } from 'firebase/firestore';
import { db, auth } from '../firebase';

interface WishlistContextType {
  wishlistItems: string[]; // Array of product IDs
  toggleWishlist: (productId: string) => Promise<void>;
  isInWishlist: (productId: string) => boolean;
  loading: boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [wishlistItems, setWishlistItems] = useState<string[]>([]);
  const [wishlistDocIds, setWishlistDocIds] = useState<Record<string, string>>({}); // productId -> wishlistDocId
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged((user) => {
      if (user) {
        const q = query(collection(db, 'wishlist'), where('userId', '==', user.uid));
        const unsubscribeWishlist = onSnapshot(q, (snapshot) => {
          const items: string[] = [];
          const docIds: Record<string, string> = {};
          snapshot.docs.forEach((doc) => {
            const data = doc.data();
            items.push(data.productId);
            docIds[data.productId] = doc.id;
          });
          setWishlistItems(items);
          setWishlistDocIds(docIds);
          setLoading(false);
        });
        return () => unsubscribeWishlist();
      } else {
        setWishlistItems([]);
        setWishlistDocIds({});
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const toggleWishlist = async (productId: string) => {
    if (!auth.currentUser) {
      throw new Error('Please login to save products.');
    }

    const existingDocId = wishlistDocIds[productId];

    if (existingDocId) {
      // Remove from wishlist
      await deleteDoc(doc(db, 'wishlist', existingDocId));
    } else {
      // Add to wishlist
      await addDoc(collection(db, 'wishlist'), {
        userId: auth.currentUser.uid,
        productId,
        createdAt: serverTimestamp()
      });
    }
  };

  const isInWishlist = (productId: string) => {
    return wishlistItems.includes(productId);
  };

  return (
    <WishlistContext.Provider value={{ wishlistItems, toggleWishlist, isInWishlist, loading }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
}
