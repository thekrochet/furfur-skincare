import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, doc, getDoc, getDocs, addDoc, onSnapshot, query, where, limit, orderBy, Timestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { motion } from 'framer-motion';
import { ArrowLeft, Loader2, Star } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import { useCart } from '../context/CartContext';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface Variant {
  size: string;
  mrp: number;
  price: number;
}

interface Ingredient {
  name: string;
  benefit: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  images?: string[];
  skinType?: string;
  rating?: number;
  category?: string;
  benefits?: string[];
  variants?: Variant[];
  ingredients?: Ingredient[];
}

interface Review {
  id: string;
  productId: string;
  name: string;
  rating: number;
  comment: string;
  date: any;
}

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<Variant | null>(null);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [reviews, setReviews] = useState<Review[]>([]);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const { addToCart } = useCart();

  // Review Form State
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      try {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          const priceVal = Number(data.price || data.Price || data.PRICE || 0);
          const mrpVal = Number(data.mrp || data.MRP || data.oldPrice || 0);
          const categoryVal = data.category || data.Category || data.CATEGORY || "";
          const productData = { 
            id: docSnap.id, 
            ...data, 
            price: priceVal,
            mrp: mrpVal,
            category: categoryVal 
          } as any as Product;
          setProduct(productData);
          
          if (productData.images && productData.images.length > 0) {
            setSelectedImage(productData.images[0]);
          } else {
            setSelectedImage(productData.image);
          }
          
          if (productData.variants && productData.variants.length > 0) {
            setSelectedVariant(productData.variants[0]);
          }
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `products/${id}`);
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  useEffect(() => {
    if (!id) return;
    const q = query(
      collection(db, 'reviews'),
      where('productId', '==', id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reviewsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      
      // Sort locally since we might not have a composite index for where + orderBy
      reviewsData.sort((a, b) => {
        const dateA = a.date?.toMillis ? a.date.toMillis() : 0;
        const dateB = b.date?.toMillis ? b.date.toMillis() : 0;
        return dateB - dateA;
      });

      setReviews(reviewsData);
      setReviewsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reviews');
      setReviewsLoading(false);
    });

    return () => unsubscribe();
  }, [id]);

  useEffect(() => {
    const fetchRelatedProducts = async () => {
      if (!product || !product.category) return;
      
      try {
        const q = query(
          collection(db, 'products'),
          where('category', '==', product.category),
          limit(10)
        );
        
        const querySnapshot = await getDocs(q);
        const products = querySnapshot.docs
          .map(doc => {
            const data = doc.data();
            const priceVal = Number(data.price || data.Price || data.PRICE || 0);
            const mrpVal = Number(data.mrp || data.MRP || data.oldPrice || 0);
            const categoryVal = data.category || data.Category || data.CATEGORY || "";
            return { 
              id: doc.id, 
              ...data, 
              price: priceVal, 
              mrp: mrpVal,
              category: categoryVal 
            } as any as Product;
          })
          .filter(p => p.id !== product.id)
          .slice(0, 4);
        
        setRelatedProducts(products);
      } catch (error) {
        console.error("Error fetching related products:", error);
      }
    };

    fetchRelatedProducts();
  }, [product]);

  const handleAddToCart = () => {
    if (product) {
      const priceToUse = selectedVariant ? selectedVariant.price : product.price;
      const nameToUse = selectedVariant ? `${product.name} (${selectedVariant.size})` : product.name;
      
      addToCart({
        id: selectedVariant ? `${product.id}-${selectedVariant.size}` : product.id,
        name: nameToUse,
        price: `₹${priceToUse}`,
        image: product.image
      });
    }
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !reviewName.trim() || !reviewComment.trim()) return;

    setSubmittingReview(true);
    try {
      await addDoc(collection(db, 'reviews'), {
        productId: id,
        name: reviewName.trim(),
        rating: reviewRating,
        comment: reviewComment.trim(),
        date: Timestamp.now()
      });
      setReviewName('');
      setReviewRating(5);
      setReviewComment('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'reviews');
    } finally {
      setSubmittingReview(false);
    }
  };

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((acc, rev) => acc + rev.rating, 0) / reviews.length).toFixed(1)
    : '0.0';

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="w-10 h-10 text-primary animate-spin" />
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow pt-32 pb-20 flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-serif text-3xl text-primary mb-4">Product Not Found</h1>
            <Link to="/shop" className="text-gray-600 hover:text-primary underline">Back to Shop</Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/shop" className="inline-flex items-center text-gray-500 hover:text-primary transition-colors mb-8">
            <ArrowLeft size={16} className="mr-2" />
            Back to Shop
          </Link>

          {/* Product Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-24">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex flex-col gap-4"
            >
              <div className="aspect-[4/5] bg-[#F5F5F5] rounded-2xl overflow-hidden">
                <img 
                  src={selectedImage || undefined} 
                  alt={product.name} 
                  className="w-full h-full object-cover object-center"
                  referrerPolicy="no-referrer"
                />
              </div>
              
              {/* Thumbnail Gallery */}
              {product.images && product.images.length > 1 && (
                <div className="flex gap-3 overflow-x-auto pb-2 snap-x">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(img)}
                      className={`relative flex-shrink-0 w-20 h-24 rounded-xl overflow-hidden snap-start transition-all ${
                        selectedImage === img ? 'ring-2 ring-black ring-offset-2' : 'opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img 
                        src={img || undefined} 
                        alt={`${product.name} thumbnail ${idx + 1}`} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </button>
                  ))}
                </div>
              )}
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex flex-col justify-center"
            >
              <div className="flex flex-wrap gap-2 mb-6">
                {product.category && (
                  <span className="px-3 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded-full uppercase tracking-wider">
                    {product.category}
                  </span>
                )}
                {product.skinType && (
                  <span className="px-3 py-1 bg-primary/5 text-primary text-xs font-medium rounded-full uppercase tracking-wider">
                    {product.skinType}
                  </span>
                )}
              </div>

              <h1 className="font-serif text-4xl md:text-5xl text-primary mb-4">{product.name}</h1>
              
              <div className="flex items-baseline gap-4 mb-6">
                <p className="text-3xl font-semibold text-gray-900">
                  ₹{selectedVariant ? selectedVariant.price : product.price}
                </p>
                {selectedVariant && selectedVariant.mrp > selectedVariant.price && (
                  <>
                    <p className="text-lg text-gray-400 line-through">
                      MRP ₹{selectedVariant.mrp}
                    </p>
                    <span className="px-2 py-1 bg-green-50 text-green-600 text-xs font-semibold rounded-lg">
                      {Math.round(((selectedVariant.mrp - selectedVariant.price) / selectedVariant.mrp) * 100)}% OFF
                    </span>
                  </>
                )}
              </div>
              
              <div className="flex items-center gap-2 mb-8">
                <div className="flex text-black">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      size={18} 
                      className={i < Math.round(Number(averageRating)) ? "fill-current text-black" : "fill-gray-200 text-gray-200"} 
                    />
                  ))}
                </div>
                <span className="text-gray-600 font-medium">{averageRating} ★ ({reviews.length} reviews)</span>
              </div>

              <p className="text-gray-700 text-lg leading-relaxed mb-8">
                {product.description || "Science-backed formulation for radiant, balanced skin."}
              </p>

              {/* Variants Selection */}
              {product.variants && product.variants.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-sm font-bold text-primary uppercase tracking-widest mb-4">Select Size</h3>
                  <div className="flex flex-wrap gap-3">
                    {product.variants.map((variant, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedVariant(variant)}
                        className={`
                          px-6 py-3 rounded-xl border-2 transition-all font-medium
                          ${selectedVariant?.size === variant.size 
                            ? 'border-black bg-black text-white' 
                            : 'border-gray-100 bg-white text-gray-600 hover:border-gray-300'}
                        `}
                      >
                        {variant.size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Benefits Section */}
              {product.benefits && product.benefits.length > 0 && (
                <div className="mb-10">
                  <h3 className="text-sm font-bold text-primary uppercase tracking-widest mb-4">Key Benefits</h3>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {product.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-center text-gray-700">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mr-3"></div>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Ingredients Section */}
              {product.ingredients && product.ingredients.length > 0 && (
                <div className="mb-10">
                  <h3 className="text-sm font-bold text-primary uppercase tracking-widest mb-4">Key Ingredients</h3>
                  <div className="space-y-6">
                    {product.ingredients.map((ingredient, idx) => (
                      <div key={idx} className="border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                        <h4 className="font-bold text-gray-900 mb-1">{ingredient.name}</h4>
                        <p className="text-gray-600 leading-relaxed">{ingredient.benefit}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button 
                onClick={handleAddToCart}
                className="w-full bg-[#111111] text-white py-4 px-8 rounded-xl font-medium text-lg hover:bg-gray-800 active:scale-[0.98] transition-all duration-200"
              >
                Add to Cart
              </button>
            </motion.div>
          </div>

          {/* Related Products Section */}
          {relatedProducts.length > 0 && (
            <div className="max-w-7xl mx-auto mb-24">
              <h2 className="font-serif text-3xl text-primary mb-8 border-b border-gray-200 pb-4">You may also like</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-8">
                {relatedProducts.map((relatedProduct) => (
                  <ProductCard
                    key={relatedProduct.id}
                    id={relatedProduct.id}
                    name={relatedProduct.name}
                    price={relatedProduct.price}
                    image={relatedProduct.image}
                    images={relatedProduct.images}
                    category={relatedProduct.category}
                    rating={relatedProduct.rating}
                    description={relatedProduct.description}
                    variants={relatedProduct.variants}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Reviews Section */}
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-3xl text-primary mb-8 border-b border-gray-200 pb-4">Customer Reviews</h2>
            
            <div className="mb-10">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-4xl font-serif text-primary">{averageRating}</span>
                <div className="flex flex-col">
                  <div className="flex text-black">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={16} 
                        className={i < Math.round(Number(averageRating)) ? "fill-current text-black" : "fill-gray-200 text-gray-200"} 
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">Based on {reviews.length} reviews</span>
                </div>
              </div>
            </div>

            {reviewsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
              </div>
            ) : reviews.length > 0 ? (
              <div className="space-y-6 mb-16">
                {reviews.map((review) => (
                  <div key={review.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-medium text-primary uppercase tracking-wider text-sm">{review.name}</h3>
                      {review.date && review.date.toDate && (
                        <span className="text-sm text-gray-500">
                          {review.date.toDate().toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <div className="flex text-black mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          size={14} 
                          className={i < review.rating ? "fill-current text-black" : "fill-gray-200 text-gray-200"} 
                        />
                      ))}
                    </div>
                    <p className="text-gray-700 leading-relaxed">{review.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 py-8 mb-16">No reviews yet. Be the first to review this product!</p>
            )}

            {/* Add Review Form */}
            <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100">
              <h3 className="font-serif text-2xl text-primary mb-6">Write a Review</h3>
              <form onSubmit={submitReview} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className="focus:outline-none"
                      >
                        <Star 
                          size={24} 
                          className={star <= reviewRating ? "fill-black text-black" : "fill-gray-200 text-gray-200 hover:text-gray-400"} 
                        />
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input
                    type="text"
                    id="name"
                    required
                    value={reviewName}
                    onChange={(e) => setReviewName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">Review</label>
                  <textarea
                    id="comment"
                    required
                    rows={4}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Share your experience with this product..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={submittingReview}
                  className="bg-primary text-white px-8 py-3 rounded-xl font-medium hover:bg-gray-800 transition-colors disabled:opacity-70 flex items-center justify-center"
                >
                  {submittingReview ? (
                    <>
                      <Loader2 size={18} className="animate-spin mr-2" />
                      Submitting...
                    </>
                  ) : (
                    'Submit Review'
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Related Products Section */}
          {relatedProducts.length > 0 && (
            <div className="mt-20 border-t border-gray-100 pt-20">
              <h2 className="text-3xl font-serif text-primary mb-10">You May Also Like</h2>
              
              {/* Desktop & Tablet Grid */}
              <div className="hidden sm:grid grid-cols-2 lg:grid-cols-4 gap-8">
                {relatedProducts.map(p => (
                  <motion.div
                    key={p.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                  >
                    <ProductCard {...p} />
                  </motion.div>
                ))}
              </div>

              {/* Mobile Horizontal Scroll */}
              <div className="sm:hidden flex overflow-x-auto gap-4 pb-8 scrollbar-hide snap-x -mx-4 px-4">
                {relatedProducts.map(p => (
                  <div key={p.id} className="min-w-[280px] snap-start">
                    <ProductCard {...p} />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
