import { useLocation, Link, Navigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { CheckCircle, ShoppingBag, ArrowRight } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

export default function OrderSuccess() {
  const location = useLocation();
  const orderId = location.state?.orderId;

  if (!orderId) {
    return <Navigate to="/shop" replace />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20 flex items-center justify-center">
        <div className="max-w-md w-full px-4 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="mb-8 flex justify-center"
          >
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600">
              <CheckCircle size={48} />
            </div>
          </motion.div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="font-serif text-3xl md:text-4xl text-primary mb-4">Order Placed Successfully!</h1>
            <p className="text-gray-600 mb-8">
              Thank you for choosing Furfur. Your order has been received and is being processed.
            </p>

            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm mb-10">
              <p className="text-sm text-gray-500 uppercase tracking-widest mb-2 font-bold">Order ID</p>
              <p className="text-2xl font-mono font-bold text-primary">{orderId}</p>
            </div>

            <div className="flex flex-col gap-4">
              <Link 
                to="/shop" 
                className="w-full bg-[#111111] text-white py-4 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-gray-800 transition-all"
              >
                <ShoppingBag size={20} />
                Continue Shopping
              </Link>
              <Link 
                to="/" 
                className="text-gray-500 hover:text-primary font-medium flex items-center justify-center gap-1 transition-colors"
              >
                Back to Home
                <ArrowRight size={16} />
              </Link>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
