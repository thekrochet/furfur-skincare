import { useState, useEffect } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db, auth } from '../firebase';
import Navbar from '../components/Navbar';
import ProductCard from '../components/ProductCard';
import Footer from '../components/Footer';
import ProductCardSkeleton from '../components/skeleton/ProductCardSkeleton';
import { Loader2, Search, X, Filter } from 'lucide-react';
import { motion } from 'framer-motion';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface Product {
  id: string;
  name: string;
  price: any;
  description: string;
  image: string;
  images?: string[];
  skinType: string;
  rating: number;
  category?: string;
  variants?: any[];
}

const CATEGORIES = ['All', 'Serum', 'Facewash', 'Moisturizer', 'Sunscreen'];
const SKIN_TYPES = ['All', 'Oily', 'Dry', 'Combination', 'Sensitive'];
const PRICE_RANGES = ['All', '₹0 - ₹500', '₹500 - ₹1000', '₹1000+'];

export default function Shop() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSkinType, setSelectedSkinType] = useState('All');
  const [selectedPriceRange, setSelectedPriceRange] = useState('All');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const path = 'products';
    const q = query(collection(db, path));

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        console.log(`Firestore Snapshot received. Document count: ${snapshot.docs.length}`);
        if (snapshot.docs.length > 0) {
          console.log("First document data:", snapshot.docs[0].data());
        } else {
          console.warn("No documents found in 'products' collection. Please ensure you have added documents to the correct database and collection.");
        }
        
        const productsData = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            name: data.name,
            description: data.description,
            image: data.image,
            category: data.category || data.Category || data.CATEGORY || "",
            rating: data.rating,
            skinType: data.skinType,
            price: Number(data.price),
            mrp: Number(data.mrp || data.MRP || data.oldPrice || 0),
            variants: data.variants || []
          };
        }) as Product[];
        setProducts(productsData);
        setLoading(false);
      }, 
      (err) => {
        setError("Failed to load products. Please check your connection.");
        setLoading(false);
        handleFirestoreError(err, OperationType.LIST, path);
      }
    );

    return () => unsubscribe();
  }, []);

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || 
                           (product.category && product.category.toLowerCase().trim() === selectedCategory.toLowerCase().trim());
                           
    const matchesSkinType = selectedSkinType === 'All' ||
                           (product.skinType && product.skinType.toLowerCase().trim() === selectedSkinType.toLowerCase().trim());
                           
    let matchesPrice = true;
    if (selectedPriceRange !== 'All') {
      const price = product.variants && product.variants.length > 0 ? product.variants[0].price : product.price;
      if (selectedPriceRange === '₹0 - ₹500') {
        matchesPrice = price >= 0 && price <= 500;
      } else if (selectedPriceRange === '₹500 - ₹1000') {
        matchesPrice = price > 500 && price <= 1000;
      } else if (selectedPriceRange === '₹1000+') {
        matchesPrice = price > 1000;
      }
    }

    return matchesSearch && matchesCategory && matchesSkinType && matchesPrice;
  });

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h1 className="font-serif text-4xl md:text-5xl text-primary mb-4">Shop All</h1>
            <p className="text-gray-700 text-lg max-w-2xl mx-auto">
              Explore our full range of science-backed skincare essentials.
            </p>
          </div>

          {/* Search and Filters */}
          <div className="mb-12 space-y-4">
            {/* Search Bar & Filter Toggle */}
            <div className="max-w-3xl mx-auto flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search skincare products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-12 py-3.5 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-primary transition-all shadow-sm focus:shadow-md"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-primary transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className={`px-5 py-3.5 rounded-xl flex items-center gap-2 transition-all font-medium border ${
                  showFilters || selectedCategory !== 'All' || selectedSkinType !== 'All' || selectedPriceRange !== 'All'
                    ? 'bg-black text-white border-black shadow-md' 
                    : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50 shadow-sm'
                }`}
              >
                <Filter size={20} />
                <span className="hidden sm:inline">Filters</span>
              </button>
            </div>

            {/* Filter Panel */}
            {showFilters && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-3xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 bg-gray-50 rounded-2xl border border-gray-100"
              >
                <div className="flex flex-col">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">Category</label>
                  <select 
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
                  >
                    {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>

                <div className="flex flex-col">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">Skin Type</label>
                  <select 
                    value={selectedSkinType}
                    onChange={(e) => setSelectedSkinType(e.target.value)}
                    className="px-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
                  >
                    {SKIN_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
                  </select>
                </div>

                <div className="flex flex-col">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">Price Range</label>
                  <select 
                    value={selectedPriceRange}
                    onChange={(e) => setSelectedPriceRange(e.target.value)}
                    className="px-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
                  >
                    {PRICE_RANGES.map(range => <option key={range} value={range}>{range}</option>)}
                  </select>
                </div>
              </motion.div>
            )}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10">
              {[...Array(8)].map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-20">
              <p className="text-red-500 font-medium">{error}</p>
              <button 
                onClick={() => window.location.reload()}
                className="mt-4 text-primary underline font-medium"
              >
                Try Again
              </button>
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-text/60 font-medium">No products found. Check back soon!</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-100 shadow-sm">
              <p className="text-gray-500 text-lg mb-4">No products match your search or filter.</p>
              <button 
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                  setSelectedSkinType('All');
                  setSelectedPriceRange('All');
                }}
                className="text-primary font-bold hover:underline"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10">
              {filteredProducts.map((product) => (
                <ProductCard 
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  price={product.price}
                  image={product.image}
                  images={product.images}
                  rating={product.rating}
                  description={product.description}
                  variants={product.variants}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
