import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { auth, db } from '../firebase';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Loader2, ShoppingBag, ChevronRight, Package, Calendar, CreditCard } from 'lucide-react';

export default function MyOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const q = query(
            collection(db, 'orders'),
            where('userId', '==', user.uid),
            orderBy('createdAt', 'desc')
          );
          const querySnapshot = await getDocs(q);
          const ordersData = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          }));
          setOrders(ordersData);
        } catch (error) {
          console.error("Error fetching orders:", error);
        }
      } else {
        navigate('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="w-10 h-10 text-primary animate-spin" />
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10 flex items-center justify-between">
            <div>
              <h1 className="font-serif text-3xl md:text-4xl text-primary mb-2">My Orders</h1>
              <p className="text-gray-500">Track your skincare journey</p>
            </div>
            <Link to="/account" className="text-sm font-medium text-primary hover:underline">Back to Account</Link>
          </div>

          {orders.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-gray-100 shadow-sm text-center">
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center text-gray-300 mx-auto mb-6">
                <ShoppingBag size={40} />
              </div>
              <h2 className="text-xl font-serif text-primary mb-2">No orders yet</h2>
              <p className="text-gray-500 mb-8">Start your skincare routine today!</p>
              <Link to="/shop" className="inline-block bg-[#111111] text-white px-8 py-3 rounded-xl font-medium hover:bg-gray-800 transition-all">
                Shop Now
              </Link>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((order) => (
                <div key={order.id} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-gray-50 bg-gray-50/50 flex flex-wrap justify-between items-center gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-primary border border-gray-100">
                        <Package size={20} />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Order ID</p>
                        <p className="font-mono font-bold text-primary">{order.orderId || order.id.slice(0, 8)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Date</p>
                        <p className="text-sm font-medium text-gray-900">{order.createdAt?.toDate().toLocaleDateString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Total</p>
                        <p className="text-sm font-bold text-gray-900">₹{order.totalPrice}</p>
                      </div>
                      <div className="px-3 py-1 bg-green-50 text-green-600 text-[10px] font-bold rounded-full uppercase tracking-widest">
                        {order.orderStatus}
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="space-y-4">
                      {order.items?.map((item: any, idx: number) => (
                        <div key={idx} className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-gray-50 rounded-lg overflow-hidden border border-gray-100 flex-shrink-0">
                            <img src={item.image || undefined} alt={item.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900 line-clamp-1">{item.name}</p>
                            <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                          </div>
                          <p className="text-sm font-bold text-gray-900">₹{parseFloat(item.price.replace(/[^0-9.]/g, '')) * item.quantity}</p>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6 pt-6 border-t border-gray-50 flex justify-between items-center">
                      <div className="flex items-center gap-2 text-gray-500 text-sm">
                        <CreditCard size={16} />
                        <span>Paid via {order.paymentMethod}</span>
                      </div>
                      <button className="text-sm font-bold text-primary hover:underline flex items-center gap-1">
                        View Details
                        <ChevronRight size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
