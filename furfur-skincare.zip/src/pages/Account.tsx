import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signOut, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Loader2, User, Mail, ShoppingBag, LogOut, ChevronRight, LayoutDashboard } from 'lucide-react';

export default function Account() {
  const [user, setUser] = useState<any>(null);
  const [userData, setUserData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const docRef = doc(db, 'users', currentUser.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setUserData(docSnap.data());
          }
        } catch (error) {
          console.error("Error fetching user data:", error);
        }
      } else {
        navigate('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/');
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="w-10 h-10 text-primary animate-spin" />
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10">
            <h1 className="font-serif text-3xl md:text-4xl text-primary mb-2">My Account</h1>
            <p className="text-gray-500">Manage your profile and track your orders</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Profile Info */}
            <div className="md:col-span-1 space-y-6">
              <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-primary/5 rounded-full flex items-center justify-center text-primary">
                    <User size={32} />
                  </div>
                  <div>
                    <h2 className="font-bold text-gray-900">{userData?.name || 'User'}</h2>
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Member since {userData?.createdAt?.toDate().getFullYear() || '2026'}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-gray-600">
                    <Mail size={18} />
                    <span className="text-sm">{user?.email}</span>
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="w-full mt-8 flex items-center justify-center gap-2 text-red-500 font-medium hover:bg-red-50 py-3 rounded-xl transition-colors"
                >
                  <LogOut size={18} />
                  Log Out
                </button>
              </div>
            </div>

            {/* Account Actions */}
            <div className="md:col-span-2 space-y-4">
              {user?.email?.toLowerCase().trim() === "mohitswami855@gmail.com" && (
                <Link
                  to="/admin"
                  className="flex items-center justify-between bg-black p-6 rounded-3xl border border-black shadow-lg hover:bg-gray-900 transition-all group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-white">
                      <LayoutDashboard size={24} />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-lg">Admin Dashboard</h3>
                      <p className="text-sm text-gray-400">Manage products, orders, and site data</p>
                    </div>
                  </div>
                  <ChevronRight className="text-white group-hover:translate-x-1 transition-transform" />
                </Link>
              )}

              <Link
                to="/orders"
                className="flex items-center justify-between bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:border-primary transition-all group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center text-primary">
                    <ShoppingBag size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">My Orders</h3>
                    <p className="text-sm text-gray-500">View and track your order history</p>
                  </div>
                </div>
                <ChevronRight className="text-gray-400 group-hover:translate-x-1 transition-transform" />
              </Link>

              <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100 text-center">
                <p className="text-gray-500 text-sm italic">"Your skin is an investment, not an expense."</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
