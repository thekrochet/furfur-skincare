import { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import Navbar from '../components/Navbar';
import ProductCard from '../components/ProductCard';
import Footer from '../components/Footer';
import ProductCardSkeleton from '../components/skeleton/ProductCardSkeleton';
import { useWishlist } from '../context/WishlistContext';
import { Heart, ShoppingBag, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  skinType: string;
  rating: number;
  category?: string;
  variants?: any[];
}

export default function Wishlist() {
  const { wishlistItems, loading: wishlistLoading } = useWishlist();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((currentUser) => {
      setUser(currentUser);
      if (!currentUser && !wishlistLoading) {
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, [wishlistLoading]);

  useEffect(() => {
    const fetchWishlistProducts = async () => {
      if (!user || wishlistItems.length === 0) {
        setProducts([]);
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        // Firestore 'in' query is limited to 10 items
        // For simplicity and to handle more than 10, we'll fetch in chunks or fetch all and filter
        // Given it's a small catalog, we'll fetch all products and filter for now
        // In a real large-scale app, we'd fetch specific IDs in chunks of 10
        const productsRef = collection(db, 'products');
        const snapshot = await getDocs(productsRef);
        
        const allProducts = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Product[];

        const wishlistProducts = allProducts.filter(p => wishlistItems.includes(p.id));
        setProducts(wishlistProducts);
      } catch (error) {
        console.error("Error fetching wishlist products:", error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchWishlistProducts();
    }
  }, [user, wishlistItems]);

  if (!user && !loading) {
    return (
      <div className="min-h-screen flex flex-col bg-white">
        <Navbar />
        <main className="flex-grow flex items-center justify-center px-4">
          <div className="text-center max-w-md">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart size={32} className="text-gray-300" />
            </div>
            <h1 className="font-serif text-3xl text-primary mb-4">Your Wishlist</h1>
            <p className="text-gray-600 mb-8">Please login to view and save your favorite products to your wishlist.</p>
            <Link 
              to="/login" 
              className="inline-block bg-black text-white px-8 py-4 text-sm tracking-widest uppercase font-medium hover:bg-gray-800 transition-colors w-full"
            >
              Login to Account
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h1 className="font-serif text-4xl md:text-5xl text-primary mb-4">My Wishlist</h1>
            <p className="text-gray-600 text-lg">
              {products.length} {products.length === 1 ? 'item' : 'items'} saved for later.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10">
              {[...Array(4)].map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-24 bg-gray-50 rounded-3xl border border-dashed border-gray-200">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                <Heart size={24} className="text-gray-300" />
              </div>
              <h2 className="text-2xl font-serif text-primary mb-3">Your wishlist is empty</h2>
              <p className="text-gray-500 mb-8 max-w-xs mx-auto">Explore our collection and save your favorite products for later.</p>
              <Link 
                to="/shop" 
                className="inline-flex items-center gap-2 bg-black text-white px-8 py-4 text-sm tracking-widest uppercase font-medium hover:bg-gray-800 transition-all group"
              >
                Start Shopping
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10">
              {products.map((product) => (
                <ProductCard 
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  price={product.price}
                  image={product.image}
                  rating={product.rating}
                  description={product.description}
                  variants={product.variants}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
