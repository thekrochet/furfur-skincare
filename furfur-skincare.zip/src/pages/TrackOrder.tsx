import React, { useState } from 'react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../firebase';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Search, Package, CheckCircle2, Truck, Home, Clock } from 'lucide-react';

type OrderStatus = 'Placed' | 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered';

const statusSteps: { status: OrderStatus; icon: any; label: string }[] = [
  { status: 'Placed', icon: CheckCircle2, label: 'Order Placed' },
  { status: 'Processing', icon: Clock, label: 'Processing' },
  { status: 'Shipped', icon: Truck, label: 'Shipped' },
  { status: 'Out for Delivery', icon: Package, label: 'Out for Delivery' },
  { status: 'Delivered', icon: Home, label: 'Delivered' },
];

export default function TrackOrder() {
  const [orderId, setOrderId] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState('');

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setOrder(null);

    try {
      const q = query(
        collection(db, 'orders'),
        where('orderId', '==', orderId.trim()),
        where('phone', '==', phone.trim()),
        limit(1)
      );

      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        setOrder({ id: querySnapshot.docs[0].id, ...querySnapshot.docs[0].data() });
      } else {
        setError('Order not found. Please check your Order ID and Phone Number.');
      }
    } catch (err) {
      console.error("Error tracking order:", err);
      setError('An error occurred while fetching order details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusIndex = (status: string) => {
    const index = statusSteps.findIndex(s => s.status.toLowerCase() === status?.toLowerCase());
    return index === -1 ? 0 : index;
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-serif text-3xl md:text-4xl text-primary mb-4">Track Your Order</h1>
            <p className="text-gray-500">Enter your details to see the current status of your skincare journey.</p>
          </div>

          <div className="max-w-md mx-auto mb-12">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
              <form onSubmit={handleTrack} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Order ID</label>
                  <input
                    type="text"
                    required
                    value={orderId}
                    onChange={(e) => setOrderId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-primary outline-none transition-all"
                    placeholder="e.g. FUR-12345"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-primary outline-none transition-all"
                    placeholder="10-digit number"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#111111] text-white py-4 rounded-xl font-medium hover:bg-gray-800 transition-all disabled:opacity-70 flex items-center justify-center"
                >
                  {loading ? (
                    <Loader2 size={20} className="animate-spin" />
                  ) : (
                    <>
                      <Search size={18} className="mr-2" />
                      Track Order
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="max-w-md mx-auto bg-red-50 text-red-600 p-4 rounded-xl text-center text-sm border border-red-100"
              >
                {error}
              </motion.div>
            )}

            {order && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* Status Tracker */}
                <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                  <h2 className="text-xl font-serif text-primary mb-10 text-center">Order Status</h2>
                  
                  <div className="max-w-md mx-auto">
                    <div className="space-y-0">
                      {statusSteps.map((step, index) => {
                        const statusIndex = getStatusIndex(order.orderStatus);
                        const isActive = index <= statusIndex;
                        const isCurrent = index === statusIndex;
                        const isLast = index === statusSteps.length - 1;
                        const Icon = step.icon;

                        return (
                          <div key={step.status} className="relative flex gap-6 pb-10 last:pb-0">
                            {/* Vertical Line */}
                            {!isLast && (
                              <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-gray-100 -z-0">
                                <motion.div 
                                  initial={{ height: 0 }}
                                  animate={{ height: isActive && index < statusIndex ? '100%' : '0%' }}
                                  className="w-full bg-primary"
                                  transition={{ duration: 0.5, delay: index * 0.1 }}
                                />
                              </div>
                            )}

                            <div className="relative z-10">
                              <div 
                                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                                  isActive ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-white text-gray-300 border-2 border-gray-100'
                                } ${isCurrent ? 'scale-110' : ''}`}
                              >
                                {isActive && !isCurrent ? (
                                  <CheckCircle2 size={20} />
                                ) : (
                                  <Icon size={20} />
                                )}
                              </div>
                            </div>

                            <div className="flex flex-col justify-center">
                              <p className={`text-sm font-bold uppercase tracking-widest ${
                                isActive ? 'text-primary' : 'text-gray-400'
                              }`}>
                                {step.label}
                              </p>
                              {isActive && (
                                <p className="text-xs text-gray-500 mt-1">
                                  {isCurrent ? 'Current Status' : 'Completed'}
                                </p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Order Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                    <h3 className="text-lg font-serif text-primary mb-6">Order Information</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between py-2 border-b border-gray-50">
                        <span className="text-sm text-gray-500">Order ID</span>
                        <span className="text-sm font-mono font-bold text-primary">{order.orderId}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-50">
                        <span className="text-sm text-gray-500">Customer Name</span>
                        <span className="text-sm font-medium text-gray-900">{order.name}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-50">
                        <span className="text-sm text-gray-500">Order Date</span>
                        <span className="text-sm font-medium text-gray-900">{order.createdAt?.toDate().toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-50">
                        <span className="text-sm text-gray-500">Payment Method</span>
                        <span className="text-sm font-medium text-gray-900 uppercase">{order.paymentMethod}</span>
                      </div>
                      <div className="flex justify-between py-2 pt-4">
                        <span className="text-base font-bold text-primary">Total Amount</span>
                        <span className="text-base font-bold text-primary">₹{order.totalPrice}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                    <h3 className="text-lg font-serif text-primary mb-6">Items Ordered</h3>
                    <div className="space-y-4">
                      {order.items?.map((item: any, idx: number) => (
                        <div key={idx} className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-gray-50 rounded-lg overflow-hidden border border-gray-100 flex-shrink-0">
                            <img src={item.image || undefined} alt={item.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900 line-clamp-1">{item.name}</p>
                            <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                          </div>
                          <p className="text-sm font-bold text-gray-900">₹{parseFloat(item.price.toString().replace(/[^0-9.]/g, '')) * item.quantity}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      <Footer />
    </div>
  );
}
