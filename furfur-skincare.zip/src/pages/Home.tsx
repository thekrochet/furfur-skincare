import React, { useState, useEffect } from 'react';
import { collection, query, limit, onSnapshot, orderBy, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { motion, useAnimationControls } from 'motion/react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import ProductCard from '../components/ProductCard';
import Footer from '../components/Footer';
import ReviewCard from '../components/ReviewCard';
import QuickViewModal from '../components/QuickViewModal';
import { Droplets, Sparkles, Sun, Loader2, Star, CheckCircle2 } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: any;
  category?: string;
  image: string;
  images?: string[];
  rating?: number;
  variants?: any[];
}

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: any;
}

export default function Home() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'products'), limit(4));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const products = snapshot.docs.map(doc => {
        const data = doc.data();
        const priceVal = Number(data.price !== undefined ? data.price : (data.Price !== undefined ? data.Price : (data.PRICE !== undefined ? data.PRICE : 0)));
        const mrpVal = Number(data.mrp || data.MRP || data.oldPrice || 0);
        return {
          id: doc.id,
          name: data.name || "Unknown Product",
          image: data.image || "",
          category: data.category || data.Category || data.CATEGORY || "",
          rating: data.rating || 5,
          price: priceVal,
          mrp: mrpVal,
          variants: data.variants || []
        };
      }) as Product[];
      setFeaturedProducts(products);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'reviews'), orderBy('date', 'desc'), limit(10));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reviewsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      setReviews(reviewsData);
      setReviewsLoading(false);
    }, (error) => {
      console.error("Error fetching reviews:", error);
      setReviewsLoading(false);
    });
    return () => unsubscribe();
  }, []);
  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'subscribers'), {
        email: email.toLowerCase().trim(),
        subscribedAt: serverTimestamp(),
        status: 'active'
      });
      setSubscribed(true);
      setEmail('');
    } catch (error) {
      console.error("Error subscribing:", error);
      alert("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center md:text-left">
            <div className="max-w-xl mx-auto md:mx-0">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="text-4xl sm:text-5xl md:text-6xl text-primary font-semibold leading-[1.15] tracking-[-0.02em] mb-6"
              >
                Healthy Skin <br /> Starts With Furfur
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
                className="hero-subtitle max-w-md mb-10 mx-auto md:mx-0"
              >
                Science-backed skincare for clear, balanced, and radiant skin.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
                className="mt-6"
              >
                <Link to="/shop" className="inline-block bg-primary text-white px-8 py-4 text-sm tracking-widest uppercase font-medium hover:bg-accent transition-colors duration-300">
                  Shop Now
                </Link>
              </motion.div>
            </div>
          </div>
          
          {/* Decorative background element */}
          <div className="absolute top-0 right-0 w-2/3 h-full bg-[#E2E8F0]/50 -z-10 rounded-bl-[200px] hidden md:block"></div>
          <div className="absolute top-20 right-10 w-[400px] h-[500px] -z-10 hidden lg:block">
             <img 
               src="https://images.unsplash.com/photo-1556228720-192a6af4e865?auto=format&fit=crop&q=80&w=800" 
               alt="Skincare aesthetic" 
               className="w-full h-full object-cover rounded-t-full"
               referrerPolicy="no-referrer"
             />
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-4">Featured Essentials</h2>
              <p className="text-gray-700 text-lg max-w-2xl mx-auto">Curated formulations designed to target your specific skin concerns.</p>
            </div>
            
            {loading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="w-8 h-8 text-accent animate-spin" />
              </div>
            ) : featuredProducts.length === 0 ? (
              <div className="text-center py-20 bg-background rounded-xl border border-dashed border-primary/20">
                <p className="text-text/60">No products found in Firestore. Add some to see them here!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {featuredProducts.map((product) => (
                  <ProductCard 
                    key={product.id} 
                    id={product.id}
                    name={product.name}
                    price={product.price}
                    category={product.category}
                    image={product.image}
                    images={product.images}
                    rating={product.rating}
                    variants={product.variants}
                    onQuickView={(p) => setSelectedProduct(p)}
                  />
                ))}
              </div>
            )}
            
            <div className="mt-16 text-center">
              <Link to="/shop" className="inline-block border border-primary text-primary px-8 py-3 text-sm tracking-widest uppercase font-medium hover:bg-primary hover:text-white transition-colors duration-300">
                View All Products
              </Link>
            </div>
          </div>
        </section>

        {/* Quick View Modal */}
        <QuickViewModal 
          product={selectedProduct} 
          onClose={() => setSelectedProduct(null)} 
        />

        {/* Skin Routine Section */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-4">The Furfur Routine</h2>
              <p className="text-gray-700 text-lg max-w-2xl mx-auto">Three simple steps to your best skin.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
              {/* Connecting line for desktop */}
              <div className="hidden md:block absolute top-12 left-[16%] right-[16%] h-[1px] bg-primary/20 z-0"></div>
              
              <div className="relative z-10 flex flex-col items-center text-center group">
                <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-primary/5 group-hover:border-accent transition-colors duration-300">
                  <Droplets size={32} className="text-primary group-hover:text-accent transition-colors" />
                </div>
                <h3 className="font-serif text-xl text-primary mb-3">1. Cleanse</h3>
                <p className="text-base text-gray-700 max-w-xs">Gently remove impurities and makeup without stripping your skin's natural barrier.</p>
              </div>

              <div className="relative z-10 flex flex-col items-center text-center group">
                <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-primary/5 group-hover:border-accent transition-colors duration-300">
                  <Sparkles size={32} className="text-primary group-hover:text-accent transition-colors" />
                </div>
                <h3 className="font-serif text-xl text-primary mb-3">2. Treat</h3>
                <p className="text-base text-gray-700 max-w-xs">Target specific concerns with our concentrated, science-backed serums.</p>
              </div>

              <div className="relative z-10 flex flex-col items-center text-center group">
                <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-primary/5 group-hover:border-accent transition-colors duration-300">
                  <Sun size={32} className="text-primary group-hover:text-accent transition-colors" />
                </div>
                <h3 className="font-serif text-xl text-primary mb-3">3. Moisturize</h3>
                <p className="text-base text-gray-700 max-w-xs">Lock in hydration and protect your skin throughout the day or night.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Furfur */}
        <section className="py-20 bg-primary text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div className="p-6">
                <h4 className="font-serif text-lg mb-2">Dermatologically<br/>Tested</h4>
                <div className="w-12 h-[1px] bg-accent mx-auto mt-4"></div>
              </div>
              <div className="p-6">
                <h4 className="font-serif text-lg mb-2">Natural<br/>Ingredients</h4>
                <div className="w-12 h-[1px] bg-accent mx-auto mt-4"></div>
              </div>
              <div className="p-6">
                <h4 className="font-serif text-lg mb-2">Cruelty<br/>Free</h4>
                <div className="w-12 h-[1px] bg-accent mx-auto mt-4"></div>
              </div>
              <div className="p-6">
                <h4 className="font-serif text-lg mb-2">For All<br/>Skin Types</h4>
                <div className="w-12 h-[1px] bg-accent mx-auto mt-4"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Customer Reviews */}
        <section className="py-24 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
            <div className="text-center">
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-4">Real Results</h2>
              <p className="text-gray-700 text-lg max-w-2xl mx-auto">Don't just take our word for it.</p>
            </div>
          </div>

          {reviewsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 text-accent animate-spin" />
            </div>
          ) : reviews.length > 0 ? (
            <div className="relative">
              {/* Gradient overlays for smooth fade edges */}
              <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none hidden md:block"></div>
              <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none hidden md:block"></div>

              <div className="flex overflow-x-auto md:overflow-hidden pb-8 md:pb-0 scrollbar-hide">
                <motion.div 
                  className="flex gap-6 px-4 md:px-0"
                  animate={{
                    x: [0, -1920], // Adjust based on total width
                  }}
                  transition={{
                    x: {
                      repeat: Infinity,
                      repeatType: "loop",
                      duration: 30,
                      ease: "linear",
                    },
                  }}
                  style={{ width: "max-content" }}
                  whileHover={{ animationPlayState: "paused" }}
                >
                  {/* Triple the reviews to ensure seamless loop */}
                  {[...reviews, ...reviews, ...reviews].map((review, index) => (
                    <div key={`${review.id}-${index}`} className="w-80 flex-shrink-0">
                      <ReviewCard 
                        name={review.name}
                        rating={review.rating}
                        comment={review.comment}
                        date={review.date}
                      />
                    </div>
                  ))}
                </motion.div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No reviews yet. Be the first to share your experience!</p>
            </div>
          )}
          
          <div className="mt-16 text-center">
            <Link to="/reviews" className="inline-block border border-primary text-primary px-8 py-3 text-sm tracking-widest uppercase font-medium hover:bg-primary hover:text-white transition-colors duration-300">
              View All Reviews
            </Link>
          </div>
        </section>

        {/* Newsletter */}
        <section className="py-24 bg-[#E2E8F0]/30">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="font-serif text-3xl md:text-4xl text-primary mb-4">Join The Furfur Community</h2>
            <p className="text-gray-700 text-lg mb-10">Subscribe to receive updates, access to exclusive deals, and more.</p>
            
            {subscribed ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white p-8 rounded-2xl border border-primary/10 shadow-sm max-w-md mx-auto"
              >
                <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-serif text-primary mb-2">You're on the list!</h3>
                <p className="text-gray-600">Thank you for joining our community. We'll be in touch soon.</p>
              </motion.div>
            ) : (
              <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto" onSubmit={handleSubscribe}>
                <input 
                  type="email" 
                  placeholder="Enter your email address" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-grow px-4 py-3 bg-white border border-primary/20 focus:outline-none focus:border-primary transition-colors"
                  required
                  disabled={submitting}
                />
                <button 
                  type="submit"
                  disabled={submitting}
                  className="bg-primary text-white px-8 py-3 text-sm tracking-widest uppercase font-medium hover:bg-accent transition-colors duration-300 whitespace-nowrap disabled:opacity-50"
                >
                  {submitting ? 'Subscribing...' : 'Subscribe'}
                </button>
              </form>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
