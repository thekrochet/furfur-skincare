import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Droplets, Sparkles, Sun, Wind, Activity, ShieldAlert } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const concerns = [
  {
    id: 'acne',
    name: 'Acne & Breakouts',
    description: 'Clear blemishes and prevent future breakouts with targeted ingredients.',
    icon: Activity,
  },
  {
    id: 'dry-skin',
    name: 'Dry Skin',
    description: 'Restore moisture and repair your skin barrier for a plump, hydrated look.',
    icon: Droplets,
  },
  {
    id: 'dark-spots',
    name: 'Dark Spots',
    description: 'Fade hyperpigmentation and even out your skin tone for a radiant complexion.',
    icon: Sun,
  },
  {
    id: 'oily-skin',
    name: 'Oily Skin',
    description: 'Balance sebum production and minimize pores without stripping your skin.',
    icon: Wind,
  },
  {
    id: 'fine-lines',
    name: 'Fine Lines & Wrinkles',
    description: 'Smooth and firm your skin with powerful anti-aging formulations.',
    icon: Sparkles,
  },
  {
    id: 'sensitive-skin',
    name: 'Sensitive Skin',
    description: 'Calm irritation and reduce redness with gentle, soothing ingredients.',
    icon: ShieldAlert,
  },
];

export default function SkinGuide() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="font-serif text-4xl md:text-5xl text-primary mb-4"
            >
              Skin Concerns Guide
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-gray-700 text-lg max-w-2xl mx-auto"
            >
              Find the right skincare routine for your skin problems.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {concerns.map((concern) => (
              <motion.div
                key={concern.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              >
                <Link 
                  to={`/skin-guide/${concern.id}`}
                  className="block h-full bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 group"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gray-100 mb-6 group-hover:scale-110 transition-transform duration-300">
                    <concern.icon className="w-6 h-6 text-black" />
                  </div>
                  <h3 className="font-serif text-2xl text-primary mb-3">{concern.name}</h3>
                  <p className="text-gray-600 mb-6 line-clamp-2">{concern.description}</p>
                  <div className="flex items-center text-primary font-medium group-hover:text-accent transition-colors">
                    Learn More
                    <svg className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
