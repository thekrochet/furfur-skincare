import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { motion } from 'framer-motion';
import { ArrowLeft, Loader2 } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';

const concernDetails = {
  'acne': {
    name: 'Acne & Breakouts',
    causes: 'Acne occurs when hair follicles become plugged with oil and dead skin cells. Factors like hormones, stress, diet, and certain medications can trigger or worsen acne.',
    ingredients: ['Salicylic Acid', 'Niacinamide', 'Benzoyl Peroxide', 'Retinol', 'Tea Tree Oil'],
    routine: [
      'Cleanse twice daily with a gentle, non-comedogenic cleanser.',
      'Apply a targeted treatment containing Salicylic Acid or Benzoyl Peroxide.',
      'Use a lightweight, oil-free moisturizer to keep the skin barrier healthy.',
      'Always apply a non-comedogenic sunscreen during the day.'
    ],
    skinTypeFilter: 'Acne',
  },
  'dry-skin': {
    name: 'Dry Skin',
    causes: 'Dry skin is often caused by environmental factors like cold weather, low humidity, harsh soaps, or hot showers. It can also be genetic or related to aging.',
    ingredients: ['Hyaluronic Acid', 'Ceramides', 'Glycerin', 'Squalane', 'Shea Butter'],
    routine: [
      'Use a gentle, hydrating cleanser that doesn\'t foam too much.',
      'Apply a hydrating serum containing Hyaluronic Acid on damp skin.',
      'Seal in moisture with a rich, ceramide-packed moisturizer.',
      'Consider using a facial oil at night for extra nourishment.'
    ],
    skinTypeFilter: 'Dry',
  },
  'dark-spots': {
    name: 'Dark Spots',
    causes: 'Hyperpigmentation is usually caused by sun exposure, inflammation (like post-acne marks), or hormonal changes (melasma).',
    ingredients: ['Vitamin C', 'Alpha Arbutin', 'Tranexamic Acid', 'Kojic Acid', 'Licorice Root Extract'],
    routine: [
      'Cleanse gently to avoid irritation, which can worsen pigmentation.',
      'Apply a Vitamin C serum in the morning for antioxidant protection and brightening.',
      'Use targeted brightening treatments at night.',
      'Sunscreen is absolutely crucial to prevent spots from getting darker.'
    ],
    skinTypeFilter: 'All', // Often products for all skin types target this
  },
  'oily-skin': {
    name: 'Oily Skin',
    causes: 'Oily skin is characterized by excess sebum production, often due to genetics, hormonal changes, or even using products that are too harsh and strip the skin.',
    ingredients: ['Niacinamide', 'Salicylic Acid', 'Clay', 'Green Tea Extract'],
    routine: [
      'Cleanse with a gentle foaming cleanser to remove excess oil.',
      'Use a BHA (Salicylic Acid) exfoliant to keep pores clear.',
      'Apply a lightweight, gel-based moisturizer. Do not skip moisturizer!',
      'Use a mattifying sunscreen during the day.'
    ],
    skinTypeFilter: 'Oily',
  },
  'fine-lines': {
    name: 'Fine Lines & Wrinkles',
    causes: 'Aging is a natural process where skin loses collagen and elasticity. Sun exposure, smoking, and repetitive facial expressions can accelerate this.',
    ingredients: ['Retinol', 'Peptides', 'Vitamin C', 'Hyaluronic Acid', 'AHA (Glycolic Acid)'],
    routine: [
      'Cleanse gently to maintain the skin barrier.',
      'Use an antioxidant serum (like Vitamin C) in the morning.',
      'Incorporate a Retinol or Peptide treatment at night to stimulate collagen.',
      'Moisturize well and always use sunscreen to prevent further damage.'
    ],
    skinTypeFilter: 'Mature',
  },
  'sensitive-skin': {
    name: 'Sensitive Skin',
    causes: 'Sensitive skin has a weakened barrier, making it prone to reactions from environmental stressors, harsh ingredients, or fragrances. It can also be related to conditions like rosacea or eczema.',
    ingredients: ['Centella Asiatica (Cica)', 'Aloe Vera', 'Colloidal Oatmeal', 'Ceramides', 'Panthenol'],
    routine: [
      'Keep your routine minimal. Less is more.',
      'Cleanse with a very gentle, fragrance-free cleanser.',
      'Use soothing, barrier-repairing serums and moisturizers.',
      'Always patch-test new products and avoid harsh exfoliants or strong active ingredients.'
    ],
    skinTypeFilter: 'Sensitive',
  },
};

export default function SkinConcernDetail() {
  const { concernId } = useParams<{ concernId: string }>();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const concern = concernId ? concernDetails[concernId as keyof typeof concernDetails] : null;

  useEffect(() => {
    const fetchProducts = async () => {
      if (!concern) return;
      
      try {
        const querySnapshot = await getDocs(collection(db, 'products'));
        const productsData = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        
        // Filter products based on skinType
        const filteredProducts = productsData.filter((product: any) => {
          if (!product.skinType) return false;
          // Simple matching logic: check if the product's skinType string includes our filter keyword
          return product.skinType.toLowerCase().includes(concern.skinTypeFilter.toLowerCase());
        });
        
        // If we don't find exact matches, just show a few random ones for demo purposes
        // In a real app, you'd have better tagging
        if (filteredProducts.length === 0) {
           setProducts(productsData.slice(0, 4));
        } else {
           setProducts(filteredProducts.slice(0, 4));
        }
        
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [concern]);

  if (!concern) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow pt-32 pb-20 flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-serif text-3xl text-primary mb-4">Concern Not Found</h1>
            <Link to="/skin-guide" className="text-accent hover:underline">Back to Skin Guide</Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/skin-guide" className="inline-flex items-center text-gray-500 hover:text-primary transition-colors mb-8">
            <ArrowLeft size={16} className="mr-2" />
            Back to Skin Guide
          </Link>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-gray-100 mb-16"
          >
            <h1 className="font-serif text-4xl md:text-5xl text-primary mb-8">{concern.name}</h1>
            
            <div className="space-y-10">
              <section>
                <h2 className="font-serif text-2xl text-primary mb-4">What causes this?</h2>
                <p className="text-gray-700 leading-relaxed">{concern.causes}</p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary mb-4">Ingredients that help</h2>
                <div className="flex flex-wrap gap-2">
                  {concern.ingredients.map((ingredient, idx) => (
                    <span key={idx} className="px-4 py-2 bg-gray-50 text-gray-800 rounded-full text-sm font-medium border border-gray-100">
                      {ingredient}
                    </span>
                  ))}
                </div>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-primary mb-4">Recommended Routine</h2>
                <ul className="space-y-4">
                  {concern.routine.map((step, idx) => (
                    <li key={idx} className="flex items-start">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold mr-4 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-gray-700">{step}</p>
                    </li>
                  ))}
                </ul>
              </section>
            </div>
          </motion.div>

          {/* Recommended Products */}
          <div className="mt-16">
            <h2 className="font-serif text-3xl text-primary mb-8">Recommended Products</h2>
            
            {loading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 text-accent animate-spin" />
              </div>
            ) : products.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} {...product} />
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-12 bg-white rounded-2xl border border-gray-100">
                No specific products found for this concern yet.
              </p>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
