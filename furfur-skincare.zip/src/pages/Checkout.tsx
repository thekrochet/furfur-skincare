import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { useCart } from '../context/CartContext';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Loader2, CreditCard, Truck, Upload, CheckCircle } from 'lucide-react';

export default function Checkout() {
  const { cartItems, cartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'UPI'>('COD');
  const [screenshot, setScreenshot] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Full Name is required';
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone Number is required';
    } else if (!/^\d{10}$/.test(formData.phone)) {
      newErrors.phone = 'Phone Number must be 10 digits';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formData.addressLine1.trim()) newErrors.addressLine1 = 'Address is required';
    if (!formData.city.trim()) newErrors.city = 'City is required';
    if (!formData.state.trim()) newErrors.state = 'State is required';
    if (!formData.postalCode.trim()) newErrors.postalCode = 'Postal Code is required';

    if (paymentMethod === 'UPI' && !screenshot) {
      newErrors.screenshot = 'Payment screenshot is required for UPI';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    if (cartItems.length === 0) return;

    setLoading(true);
    try {
      const orderId = `FUR-${Math.floor(10000 + Math.random() * 90000)}`;
      
      const orderData = {
        orderId,
        userId: auth.currentUser?.uid,
        name: formData.fullName,
        phone: formData.phone,
        email: formData.email,
        addressLine1: formData.addressLine1,
        addressLine2: formData.addressLine2,
        city: formData.city,
        state: formData.state,
        postalCode: formData.postalCode,
        items: cartItems,
        totalPrice: cartTotal,
        paymentMethod,
        paymentStatus: paymentMethod === 'COD' ? 'pending' : 'awaiting_verification',
        orderStatus: 'new',
        createdAt: Timestamp.now(),
        paymentScreenshot: screenshot || null
      };

      await addDoc(collection(db, 'orders'), orderData);
      
      clearCart();

      navigate('/order-success', { state: { orderId } });
    } catch (error) {
      console.error("Error placing order:", error);
      alert("Failed to place order. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-3xl md:text-4xl text-primary mb-8 text-center">Checkout</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Form Section */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-serif text-primary mb-6">Shipping Details</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 rounded-xl border ${errors.fullName ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                    placeholder="John Doe"
                  />
                  {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName}</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-2.5 rounded-xl border ${errors.phone ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                      placeholder="10-digit number"
                    />
                    {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-2.5 rounded-xl border ${errors.email ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                      placeholder="john@example.com"
                    />
                    {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 1 *</label>
                  <input
                    type="text"
                    name="addressLine1"
                    value={formData.addressLine1}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 rounded-xl border ${errors.addressLine1 ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                    placeholder="House No, Street Name"
                  />
                  {errors.addressLine1 && <p className="text-red-500 text-xs mt-1">{errors.addressLine1}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 2 (Optional)</label>
                  <input
                    type="text"
                    name="addressLine2"
                    value={formData.addressLine2}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-primary outline-none transition-all"
                    placeholder="Apartment, suite, etc."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-2.5 rounded-xl border ${errors.city ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                    />
                    {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">State *</label>
                    <input
                      type="text"
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-2.5 rounded-xl border ${errors.state ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                    />
                    {errors.state && <p className="text-red-500 text-xs mt-1">{errors.state}</p>}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Postal Code *</label>
                  <input
                    type="text"
                    name="postalCode"
                    value={formData.postalCode}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 rounded-xl border ${errors.postalCode ? 'border-red-500' : 'border-gray-200'} focus:ring-2 focus:ring-primary outline-none transition-all`}
                  />
                  {errors.postalCode && <p className="text-red-500 text-xs mt-1">{errors.postalCode}</p>}
                </div>

                <div className="pt-6">
                  <h2 className="text-xl font-serif text-primary mb-4">Payment Method</h2>
                  <div className="space-y-3">
                    <label className={`flex items-center p-4 rounded-xl border cursor-pointer transition-all ${paymentMethod === 'COD' ? 'border-primary bg-primary/5' : 'border-gray-200 hover:bg-gray-50'}`}>
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="COD"
                        checked={paymentMethod === 'COD'}
                        onChange={() => setPaymentMethod('COD')}
                        className="w-4 h-4 text-primary focus:ring-primary"
                      />
                      <div className="ml-3 flex items-center gap-2">
                        <Truck size={20} className="text-gray-600" />
                        <span className="font-medium text-gray-900">Cash on Delivery (COD)</span>
                      </div>
                    </label>

                    <label className={`flex items-center p-4 rounded-xl border cursor-pointer transition-all ${paymentMethod === 'UPI' ? 'border-primary bg-primary/5' : 'border-gray-200 hover:bg-gray-50'}`}>
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="UPI"
                        checked={paymentMethod === 'UPI'}
                        onChange={() => setPaymentMethod('UPI')}
                        className="w-4 h-4 text-primary focus:ring-primary"
                      />
                      <div className="ml-3 flex items-center gap-2">
                        <CreditCard size={20} className="text-gray-600" />
                        <span className="font-medium text-gray-900">UPI Payment</span>
                      </div>
                    </label>
                  </div>

                  {paymentMethod === 'UPI' && (
                    <div className="mt-6 p-6 bg-gray-50 rounded-2xl border border-gray-200 space-y-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600 mb-2">Scan QR or use UPI ID to pay</p>
                        <p className="font-bold text-lg text-primary select-all">mohitswami855-3@okaxis</p>
                        <div className="mt-4 w-40 h-40 mx-auto bg-white p-2 border border-gray-200 rounded-lg flex items-center justify-center">
                          {/* Placeholder for QR Code */}
                          <img 
                            src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=mohitswami855-3@okaxis&pn=Furfur%20Skincare" 
                            alt="UPI QR Code"
                            className="w-full h-full"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Upload Payment Screenshot *</label>
                        <div className="relative">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="hidden"
                            id="screenshot-upload"
                          />
                          <label
                            htmlFor="screenshot-upload"
                            className={`flex items-center justify-center w-full px-4 py-3 rounded-xl border-2 border-dashed cursor-pointer transition-all ${errors.screenshot ? 'border-red-500 bg-red-50' : 'border-gray-300 hover:border-primary hover:bg-gray-50'}`}
                          >
                            {screenshot ? (
                              <div className="flex items-center text-green-600">
                                <CheckCircle size={20} className="mr-2" />
                                <span className="text-sm font-medium">Screenshot Uploaded</span>
                              </div>
                            ) : (
                              <div className="flex items-center text-gray-500">
                                <Upload size={20} className="mr-2" />
                                <span className="text-sm font-medium">Click to upload screenshot</span>
                              </div>
                            )}
                          </label>
                        </div>
                        {errors.screenshot && <p className="text-red-500 text-xs mt-1">{errors.screenshot}</p>}
                      </div>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={loading || cartItems.length === 0}
                  className="w-full bg-[#111111] text-white py-4 rounded-xl font-medium text-lg hover:bg-gray-800 transition-all disabled:opacity-70 flex items-center justify-center mt-8"
                >
                  {loading ? (
                    <>
                      <Loader2 size={20} className="animate-spin mr-2" />
                      Processing...
                    </>
                  ) : (
                    `Place Order (₹${cartTotal})`
                  )}
                </button>
              </form>
            </div>

            {/* Order Summary Section */}
            <div className="lg:sticky lg:top-32 h-fit">
              <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100">
                <h2 className="text-xl font-serif text-primary mb-6">Order Summary</h2>
                <div className="space-y-4 mb-6">
                  {cartItems.map((item: any) => (
                    <div key={item.id} className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-white rounded-lg overflow-hidden border border-gray-100">
                          <img src={item.image || undefined} alt={item.name} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900 line-clamp-1">{item.name}</p>
                          <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                        </div>
                      </div>
                      <p className="text-sm font-bold text-gray-900">₹{parseFloat(item.price.replace(/[^0-9.]/g, '')) * item.quantity}</p>
                    </div>
                  ))}
                </div>
                
                <div className="border-t border-gray-200 pt-4 space-y-2">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal</span>
                    <span>₹{cartTotal}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Shipping</span>
                    <span className="text-green-600 font-medium">FREE</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-gray-900 pt-2">
                    <span>Total</span>
                    <span>₹{cartTotal}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
