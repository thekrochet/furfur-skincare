import { useState, useEffect } from 'react';
import { collection, query, limit, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Beaker, Eye, ShieldCheck, Star, Loader2 } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ReviewCard from '../components/ReviewCard';

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: any;
}

const PHILOSOPHY = [
  {
    title: 'Science First',
    description: 'We formulate products based on clinically proven ingredients.',
    icon: Beaker,
  },
  {
    title: 'Transparency',
    description: 'Every ingredient we use is clearly explained.',
    icon: Eye,
  },
  {
    title: 'Skin Friendly',
    description: 'Our products are designed to support the natural skin barrier.',
    icon: ShieldCheck,
  },
];

const INGREDIENTS = [
  'Niacinamide',
  'Hyaluronic Acid',
  'Salicylic Acid',
  'Vitamin C',
];

const REVIEWS = [
  {
    id: 1,
    name: 'Sarah M.',
    text: 'Furfur completely transformed my skin texture. The transparency in their ingredients makes me trust them completely.',
    rating: 5,
  },
  {
    id: 2,
    name: 'James L.',
    text: 'Simple, effective, and no nonsense. Exactly what I was looking for in a skincare routine.',
    rating: 5,
  },
  {
    id: 3,
    name: 'Emily R.',
    text: 'The best products I have ever used. My skin has never looked so clear and radiant.',
    rating: 5,
  },
];

export default function About() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'reviews'), orderBy('date', 'desc'), limit(10));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reviewsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      setReviews(reviewsData);
      setReviewsLoading(false);
    }, (error) => {
      console.error("Error fetching reviews:", error);
      setReviewsLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1615397323214-93b74706915c?q=80&w=2000&auto=format&fit=crop" 
              alt="Soft skincare background" 
              className="w-full h-full object-cover opacity-20"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/80 to-background"></div>
          </div>
          
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="font-serif text-4xl md:text-6xl text-primary mb-6 leading-tight"
            >
              Science Backed Skincare For Healthy Skin
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-gray-700 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed"
            >
              Furfur is built on the belief that skincare should be simple, effective, and backed by science. Our formulations focus on clinically proven ingredients that deliver real results.
            </motion.p>
          </div>
        </section>

        {/* Our Mission */}
        <section className="py-20 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-6">Our Mission</h2>
              <p className="text-gray-700 text-lg md:text-xl leading-relaxed">
                To create skincare products that are transparent, effective, and suitable for all skin types without unnecessary ingredients.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Our Philosophy */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-4">Our Philosophy</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {PHILOSOPHY.map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white p-10 rounded-2xl shadow-sm hover:shadow-md transition-shadow duration-300 border border-gray-100 text-center"
                >
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center">
                      <item.icon className="w-8 h-8 text-primary" strokeWidth={1.5} />
                    </div>
                  </div>
                  <h3 className="font-serif text-2xl text-primary mb-4">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Ingredient Transparency */}
        <section className="py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-6">Ingredient Transparency</h2>
              <p className="text-gray-700 text-lg mb-10 max-w-2xl mx-auto">
                We focus on active ingredients that are clinically proven to work. No fillers, no secrets. Just effective skincare.
              </p>
              
              <div className="flex flex-wrap justify-center gap-4">
                {INGREDIENTS.map((ingredient, index) => (
                  <motion.span
                    key={ingredient}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="px-6 py-3 bg-gray-50 border border-gray-200 rounded-full text-primary font-medium tracking-wide"
                  >
                    {ingredient}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Real Results */}
        <section className="py-24 bg-background overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
            <div className="text-center">
              <h2 className="font-serif text-3xl md:text-4xl text-primary mb-4">Real Results</h2>
              <p className="text-gray-700 text-lg max-w-2xl mx-auto">Hear from our community.</p>
            </div>
          </div>

          {reviewsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
            </div>
          ) : reviews.length > 0 ? (
            <div className="relative">
              {/* Gradient overlays for smooth fade edges */}
              <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none hidden md:block"></div>
              <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none hidden md:block"></div>

              <div className="flex overflow-x-auto md:overflow-hidden pb-8 md:pb-0 scrollbar-hide">
                <motion.div 
                  className="flex gap-6 px-4 md:px-0"
                  animate={{
                    x: [0, -1920],
                  }}
                  transition={{
                    x: {
                      repeat: Infinity,
                      repeatType: "loop",
                      duration: 30,
                      ease: "linear",
                    },
                  }}
                  style={{ width: "max-content" }}
                  whileHover={{ animationPlayState: "paused" }}
                >
                  {[...reviews, ...reviews, ...reviews].map((review, index) => (
                    <div key={`${review.id}-${index}`} className="w-80 flex-shrink-0">
                      <ReviewCard 
                        name={review.name}
                        rating={review.rating}
                        comment={review.comment}
                        date={review.date}
                      />
                    </div>
                  ))}
                </motion.div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No reviews yet. Be the first to share your experience!</p>
            </div>
          )}
          
          <div className="mt-16 text-center">
            <Link to="/reviews" className="inline-block border border-primary text-primary px-8 py-3 text-sm tracking-widest uppercase font-medium hover:bg-primary hover:text-white transition-colors duration-300">
              View All Reviews
            </Link>
          </div>
        </section>

        {/* Call To Action */}
        <section className="py-24 bg-primary text-white text-center">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-serif text-4xl md:text-5xl mb-8">Start Your Skincare Journey</h2>
              <Link 
                to="/shop"
                className="inline-block bg-white text-primary px-10 py-4 rounded-full font-medium text-lg hover:bg-gray-100 transition-colors duration-300"
              >
                Shop Now
              </Link>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
