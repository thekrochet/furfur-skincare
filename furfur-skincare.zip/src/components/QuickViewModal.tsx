import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface Variant {
  size: string;
  mrp: number;
  price: number;
}

interface Product {
  id: string;
  name: string;
  price: any;
  description: string;
  image: string;
  rating: number;
  variants?: Variant[];
}

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
}

export default function QuickViewModal({ product, onClose }: QuickViewModalProps) {
  const { addToCart } = useCart();
  const [selectedVariant, setSelectedVariant] = React.useState<Variant | null>(null);

  React.useEffect(() => {
    if (product && product.variants && product.variants.length > 0) {
      setSelectedVariant(product.variants[0]);
    } else {
      setSelectedVariant(null);
    }
  }, [product]);

  if (!product) return null;

  const currentPrice = selectedVariant ? selectedVariant.price : Number(product.price);
  const currentMRP = selectedVariant ? selectedVariant.mrp : (product as any).mrp || 0;
  const discount = currentMRP > currentPrice ? Math.round(((currentMRP - currentPrice) / currentMRP) * 100) : 0;

  const handleAddToCart = () => {
    const priceToUse = selectedVariant ? selectedVariant.price : Number(product.price);
    const nameToUse = selectedVariant ? `${product.name} (${selectedVariant.size})` : product.name;
    const idToUse = selectedVariant ? `${product.id}-${selectedVariant.size}` : product.id;

    addToCart({
      id: idToUse,
      name: nameToUse,
      price: `₹${priceToUse}`,
      image: product.image
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {product && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh]"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 p-2 bg-white/80 backdrop-blur-md rounded-full text-gray-500 hover:text-primary transition-colors shadow-sm"
            >
              <X size={20} />
            </button>

            {/* Image Section */}
            <div className="w-full md:w-1/2 aspect-square md:aspect-auto bg-gray-50">
              <img
                src={product.image || undefined}
                alt={product.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Info Section */}
            <div className="w-full md:w-1/2 p-6 sm:p-10 flex flex-col overflow-y-auto">
              <div className="mb-6">
                <h2 className="font-serif text-2xl sm:text-3xl text-primary mb-2">{product.name}</h2>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < product.rating ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium text-gray-500">({product.rating}.0 Rating)</span>
                </div>
                <div className="flex items-baseline gap-3">
                  <p className="text-3xl font-bold text-primary">₹{currentPrice}</p>
                  {currentMRP > currentPrice && (
                    <p className="text-lg text-gray-400 line-through">MRP ₹{currentMRP}</p>
                  )}
                  {discount > 0 && (
                    <span className="px-2 py-1 bg-black text-white text-[10px] font-bold rounded uppercase tracking-wider">
                      {discount}% OFF
                    </span>
                  )}
                </div>
              </div>

              {product.variants && product.variants.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-3">Select Size</h3>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((variant, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedVariant(variant)}
                        className={`px-4 py-2 rounded-xl border-2 transition-all text-sm font-medium ${
                          selectedVariant?.size === variant.size
                            ? 'border-black bg-black text-white'
                            : 'border-gray-100 hover:border-gray-200 text-gray-600'
                        }`}
                      >
                        {variant.size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="mb-8">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-3">Description</h3>
                <p className="text-gray-600 leading-relaxed">
                  {product.description || "Experience the power of science-backed skincare. Our formulations are designed to deliver visible results while maintaining your skin's natural balance."}
                </p>
              </div>

              <div className="mt-auto space-y-4">
                <button
                  onClick={handleAddToCart}
                  className="w-full bg-primary text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors"
                >
                  <ShoppingBag size={20} />
                  Add to Cart
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-2 text-sm text-gray-400 hover:text-primary transition-colors font-medium"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
