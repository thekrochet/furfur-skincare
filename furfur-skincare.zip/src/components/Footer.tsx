import { Instagram, Twitter, Facebook } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-primary text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <h2 className="font-serif text-3xl font-semibold mb-4 tracking-[-0.01em]">Furfur</h2>
            <p className="text-white/70 max-w-sm mb-6 text-sm leading-relaxed">
              Science-backed skincare for clear, balanced, and radiant skin. 
              Formulated with clinical-grade ingredients.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white/70 hover:text-accent transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white/70 hover:text-accent transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white/70 hover:text-accent transition-colors">
                <Facebook size={20} />
              </a>
              <Link to="/admin" className="text-white/70 hover:text-accent transition-colors flex items-center justify-center font-medium text-lg">
                @
              </Link>
            </div>
          </div>
          
          <div>
            <h3 className="font-serif text-lg mb-4">Quick Links</h3>
            <ul className="space-y-3 text-sm text-white/70">
              <li><Link to="/shop" className="hover:text-accent transition-colors">Shop All</Link></li>
              <li><Link to="/skin-guide" className="hover:text-accent transition-colors">Skin Guide</Link></li>
              <li><Link to="/about" className="hover:text-accent transition-colors">Our Story</Link></li>
              <li><Link to="/reviews" className="hover:text-accent transition-colors">Reviews</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-serif text-lg mb-4">Support</h3>
            <ul className="space-y-3 text-sm text-white/70">
              <li><Link to="/about" className="hover:text-accent transition-colors">FAQ</Link></li>
              <li><Link to="/about" className="hover:text-accent transition-colors">Shipping & Returns</Link></li>
              <li><Link to="/about" className="hover:text-accent transition-colors">Contact Us</Link></li>
              <li><Link to="/track-order" className="hover:text-accent transition-colors">Track Order</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/50">
          <p>&copy; {new Date().getFullYear()} Furfur Skincare. All rights reserved.</p>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
