import { useState, useEffect } from 'react';
import { Menu, ShoppingBag, X, User, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../firebase';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const { cartCount, setIsCartOpen } = useCart();
  const { wishlistItems } = useWishlist();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Admin check
        const isUserAdmin = currentUser.email?.toLowerCase().trim() === "mohitswami855@gmail.com";
        setIsAdmin(isUserAdmin);
      } else {
        setIsAdmin(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const adminLink = isAdmin && (
    <Link 
      to="/admin" 
      className="hidden md:block text-[10px] font-bold uppercase tracking-widest bg-black text-white px-3 py-1.5 rounded-full hover:bg-accent transition-colors"
    >
      Admin Panel
    </Link>
  );

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-primary/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-primary hover:text-accent transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-sm font-medium text-text hover:text-accent transition-colors">Home</Link>
            <Link to="/shop" className="text-sm font-medium text-text hover:text-accent transition-colors">Shop</Link>
            <Link to="/skin-guide" className="text-sm font-medium text-text hover:text-accent transition-colors">Skin Guide</Link>
            <Link to="/reviews" className="text-sm font-medium text-text hover:text-accent transition-colors">Reviews</Link>
          </div>

          {/* Logo */}
          <div className="flex-shrink-0 flex items-center justify-center">
            <Link to="/" className="font-serif text-3xl font-semibold tracking-[-0.01em] text-primary">
              Furfur
            </Link>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-4 lg:gap-6">
            {adminLink}
            
            <Link 
              to={user ? "/account" : "/login"} 
              className="text-primary hover:text-accent transition-colors flex items-center gap-2"
            >
              <User size={22} />
              <span className="hidden lg:inline text-sm font-medium">{user ? 'Account' : 'Login'}</span>
            </Link>

            <Link 
              to="/wishlist" 
              className="text-primary hover:text-accent transition-colors relative"
            >
              <Heart size={22} />
              {wishlistItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {wishlistItems.length}
                </span>
              )}
            </Link>
            
            <button 
              onClick={() => setIsCartOpen(true)}
              className="text-primary hover:text-accent transition-colors relative"
            >
              <ShoppingBag size={24} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-accent text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-background border-b border-primary/10">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" className="block px-3 py-2 text-base font-medium text-text hover:text-accent transition-colors">Home</Link>
            <Link to="/shop" className="block px-3 py-2 text-base font-medium text-text hover:text-accent transition-colors">Shop</Link>
            <Link to="/skin-guide" className="block px-3 py-2 text-base font-medium text-text hover:text-accent transition-colors">Skin Guide</Link>
            <Link to="/reviews" className="block px-3 py-2 text-base font-medium text-text hover:text-accent transition-colors">Reviews</Link>
            {isAdmin && (
               <Link to="/admin" className="block px-3 py-2 text-base font-bold text-accent hover:text-primary transition-colors">Admin Panel</Link>
            )}
            <Link to="/wishlist" className="block px-3 py-2 text-base font-medium text-text hover:text-accent transition-colors">Wishlist</Link>
            <Link 
              to={user ? "/account" : "/login"} 
              className="block px-3 py-2 text-base font-medium text-primary hover:text-accent transition-colors"
            >
              {user ? 'Account' : 'Login'}
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
