import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

interface ReviewCardProps {
  key?: string | number;
  name: string;
  rating: number;
  comment: string;
  date?: any;
}

export default function ReviewCard({ name, rating, comment, date }: ReviewCardProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="bg-white p-8 rounded-2xl shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] border border-gray-100 flex flex-col h-full"
    >
      <div className="flex text-black mb-4">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            size={16} 
            className={i < rating ? "fill-current text-black" : "fill-gray-200 text-gray-200"} 
          />
        ))}
      </div>
      <p className="text-gray-700 leading-relaxed mb-6 flex-grow italic">"{comment}"</p>
      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
        <span className="font-medium text-primary uppercase tracking-wider text-sm">— {name}</span>
        {date && date.toDate && (
          <span className="text-xs text-gray-400">
            {date.toDate().toLocaleDateString()}
          </span>
        )}
      </div>
    </motion.div>
  );
}
