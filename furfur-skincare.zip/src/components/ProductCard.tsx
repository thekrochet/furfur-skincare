import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight, Star, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { Link } from 'react-router-dom';
import { auth } from '../firebase';

interface Variant {
  size: string;
  mrp: number;
  price: number;
}

interface ProductCardProps {
  id?: string;
  key?: string | number;
  name: string;
  price: number;
  image: string;
  category?: string;
  rating?: number;
  description?: string;
  mrp?: number;
  oldPrice?: number;
  onQuickView?: (product: any) => void;
  variants?: Variant[];
  images?: string[];
}

export default function ProductCard({ 
  id,
  name = "Unknown Product", 
  price, 
  image = "", 
  rating = 5, 
  description, 
  mrp,
  oldPrice,
  onQuickView,
  variants,
  images
}: ProductCardProps) {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [wishlistLoading, setWishlistLoading] = useState(false);

  const currentPrice = variants && variants.length > 0 ? variants[0].price : price;
  const currentMRP = variants && variants.length > 0 ? variants[0].mrp : (mrp || oldPrice || 0);
  const discount = currentMRP > currentPrice ? Math.round(((currentMRP - currentPrice) / currentMRP) * 100) : 0;

  const productId = id || name;
  const isWishlisted = isInWishlist(productId);

  const mainImage = images && images.length > 0 ? images[0] : image;
  const hoverImage = images && images.length > 1 ? images[1] : null;

  const handleWishlistToggle = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!auth.currentUser) {
      alert("Please login to save products.");
      return;
    }

    setWishlistLoading(true);
    try {
      await toggleWishlist(productId);
    } catch (error: any) {
      alert(error.message);
    } finally {
      setWishlistLoading(false);
    }
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const itemPrice = variants && variants.length > 0 ? variants[0].price : price;
    const itemName = variants && variants.length > 0 ? `${name} (${variants[0].size})` : name;
    const itemId = variants && variants.length > 0 ? `${id || name}-${variants[0].size}` : (id || name);

    addToCart({
      id: itemId,
      name: itemName,
      price: `₹${itemPrice}`,
      image
    });
  };

  const handleCardClick = (e: React.MouseEvent) => {
    if (onQuickView) {
      e.preventDefault();
      onQuickView({ id, name, price: currentPrice, image, rating, description, variants });
    }
  };

  const CardContent = (
    <motion.div 
      className="group cursor-pointer bg-white rounded-2xl shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_30px_-4px_rgba(0,0,0,0.1)] transition-shadow duration-500 flex flex-col overflow-hidden border border-gray-100 h-full"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      onClick={handleCardClick}
    >
      {/* Top Section: Image & Slider UI */}
      <div className="relative aspect-[4/5] bg-[#F5F5F5] overflow-hidden w-full">
        <img 
          src={mainImage || undefined} 
          alt={name} 
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
          referrerPolicy="no-referrer"
        />
        {hoverImage && (
          <img 
            src={hoverImage} 
            alt={`${name} hover`} 
            className="absolute inset-0 w-full h-full object-cover object-center opacity-0 md:group-hover:opacity-100 group-hover:scale-105"
            style={{ transition: 'opacity 0.35s ease-in-out, transform 0.7s cubic-bezier(0.4, 0, 0.2, 1)' }}
            referrerPolicy="no-referrer"
          />
        )}

        {/* Wishlist Button */}
        <button 
          onClick={handleWishlistToggle}
          disabled={wishlistLoading}
          className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center z-20 shadow-sm hover:bg-white transition-all duration-300 group/wishlist"
        >
          <Heart 
            size={20} 
            className={`transition-colors duration-300 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-400 group-hover/wishlist:text-red-400'}`} 
          />
        </button>
        
        {/* Slider Arrows (UI Only) */}
        <button className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white text-gray-800 shadow-sm">
          <ChevronLeft size={18} strokeWidth={2.5} />
        </button>
        <button className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white text-gray-800 shadow-sm">
          <ChevronRight size={18} strokeWidth={2.5} />
        </button>
 
        {/* Slider Dots (UI Only) */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-gray-800"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-gray-400/60"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-gray-400/60"></div>
        </div>
      </div>

      {/* Product Info Section */}
      <div className="p-5 flex flex-col flex-grow">
        <div className="mb-1">
          <h3 className="product-title text-base text-gray-900 line-clamp-1">{name}</h3>
        </div>
        
        {description ? (
          <p className="text-base text-gray-700 line-clamp-2 mb-3 leading-relaxed">
            {description}
          </p>
        ) : (
          <p className="text-base text-gray-700 line-clamp-2 mb-3 leading-relaxed">
            Science-backed formulation for radiant, balanced skin.
          </p>
        )}

        {/* Rating */}
        <div className="flex items-center gap-1 mb-4 mt-auto">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              size={14} 
              className={i < rating ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"} 
            />
          ))}
          <span className="text-sm font-medium text-gray-600 ml-1">({rating}.0)</span>
        </div>

        {/* Price & Button */}
        <div className="flex flex-col gap-4 mt-auto">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-semibold text-gray-900">₹{currentPrice}</span>
              {currentMRP > currentPrice && (
                <span className="text-sm text-gray-400 line-through">MRP ₹{currentMRP}</span>
              )}
            </div>
            {discount > 0 && (
              <div className="mt-1">
                <span className="px-2 py-0.5 bg-black text-white text-[10px] font-semibold rounded uppercase tracking-wider">
                  {discount}% OFF
                </span>
              </div>
            )}
          </div>
          
          <button 
            onClick={handleAddToCart}
            className="w-full bg-[#111111] text-white py-3.5 px-4 rounded-xl font-medium text-sm hover:bg-gray-800 active:scale-[0.98] transition-all duration-200"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </motion.div>
  );

  if (onQuickView) {
    return CardContent;
  }

  return (
    <Link to={`/product/${id || name}`}>
      {CardContent}
    </Link>
  );
}
