import React from 'react';

export default function ReviewCardSkeleton() {
  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 flex flex-col h-full animate-pulse">
      {/* Stars Placeholder */}
      <div className="flex gap-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="w-4 h-4 bg-gray-200 rounded-full"></div>
        ))}
      </div>

      {/* Comment Placeholder */}
      <div className="space-y-3 mb-6 flex-grow">
        <div className="h-4 bg-gray-100 rounded-md w-full"></div>
        <div className="h-4 bg-gray-100 rounded-md w-11/12"></div>
        <div className="h-4 bg-gray-100 rounded-md w-4/5"></div>
      </div>

      {/* Footer Placeholder */}
      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
        <div className="h-4 bg-gray-200 rounded-md w-24"></div>
        <div className="h-3 bg-gray-100 rounded-md w-16"></div>
      </div>
    </div>
  );
}
