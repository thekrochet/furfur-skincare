import React from 'react';

export default function PageSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="h-12 bg-gray-200 rounded-md w-1/3 mx-auto mb-6"></div>
      <div className="h-6 bg-gray-100 rounded-md w-1/2 mx-auto mb-12"></div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="h-80 bg-gray-100 rounded-2xl"></div>
        ))}
      </div>
    </div>
  );
}
