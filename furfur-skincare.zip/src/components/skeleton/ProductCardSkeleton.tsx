import React from 'react';

export default function ProductCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] flex flex-col overflow-hidden border border-gray-100 animate-pulse">
      {/* Image Placeholder */}
      <div className="aspect-[4/5] bg-gray-200 w-full"></div>

      {/* Product Info Section */}
      <div className="p-5 flex flex-col flex-grow">
        <div className="h-5 bg-gray-200 rounded-md w-3/4 mb-3"></div>
        
        <div className="space-y-2 mb-4">
          <div className="h-4 bg-gray-100 rounded-md w-full"></div>
          <div className="h-4 bg-gray-100 rounded-md w-5/6"></div>
        </div>

        {/* Rating Placeholder */}
        <div className="flex items-center gap-1 mb-4 mt-auto">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="w-3.5 h-3.5 bg-gray-200 rounded-full"></div>
          ))}
          <div className="w-8 h-4 bg-gray-100 rounded-md ml-1"></div>
        </div>

        {/* Price & Button Placeholder */}
        <div className="flex flex-col gap-4 mt-auto">
          <div className="h-6 bg-gray-200 rounded-md w-1/3"></div>
          <div className="w-full h-12 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    </div>
  );
}
